package com.vondear.rxtools.interfaces;

/**
 * Created by Administrator on 2017/4/19.
 */

public interface onRequestListener {
    void onSuccess(String s);

    void onError(String s);
}
