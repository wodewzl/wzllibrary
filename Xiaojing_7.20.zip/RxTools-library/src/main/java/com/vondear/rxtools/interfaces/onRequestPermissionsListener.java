package com.vondear.rxtools.interfaces;

/**
 * Created by Administrator on 2017/3/10.
 */

public interface onRequestPermissionsListener {
    void onRequestBefore();

    void onRequestLater();
}
