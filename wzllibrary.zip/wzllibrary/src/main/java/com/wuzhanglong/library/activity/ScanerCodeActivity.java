package com.wuzhanglong.library.activity;

import com.vondear.rxtools.activity.ActivityScanerCode;

public class ScanerCodeActivity extends ActivityScanerCode {



}
