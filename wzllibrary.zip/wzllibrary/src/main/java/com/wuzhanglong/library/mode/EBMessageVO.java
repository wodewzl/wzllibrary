package com.wuzhanglong.library.mode;

/**
 * Created by Administrator on 2017/2/25.
 */

public class EBMessageVO {
    public String message;
    public String[] params;

    public EBMessageVO(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String[] getParams() {
        return params;
    }

    public void setParams(String[] params) {
        this.params = params;
    }
}
