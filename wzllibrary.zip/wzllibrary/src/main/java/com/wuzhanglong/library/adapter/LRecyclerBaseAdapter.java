package com.wuzhanglong.library.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

/**
 * Created by Administrator on 2017/3/13.
 */
// CommonAdapter RecyclerView.Adapter
public abstract class LRecyclerBaseAdapter<M> extends RecyclerView.Adapter {
    protected List<M> mList = new ArrayList<>();
    protected Context mContext;
    public boolean mIsEmpty = false;
    public static final int EMPTY_VIEW=1;
//    public static final int CONTENT_VIEW=2;

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {

    }


    @Override
    public int getItemViewType(int position) {
        if(mList.size() == 0){
            return EMPTY_VIEW;
        } else {
            return super.getItemViewType(position);
        }
    }

    @Override
    public int getItemCount() {
//        return mList.size();
        if (mList == null || mList.size() == 0) {
            mIsEmpty = true;
            return 1;
        } else {
            mIsEmpty = false;
            return mList.size();
        }
    }

    public List<M> getDataList() {
        return mList;
    }

    public void setDataList(Collection<M> list) {
        this.mList.clear();
        this.mList.addAll(list);
        notifyDataSetChanged();
    }

    public void addAll(Collection<M> list) {
        int lastIndex = this.mList.size();
        if (this.mList.addAll(list)) {
            notifyItemRangeInserted(lastIndex, list.size());
        }
    }

    public void updateData(List<M> list) {
        mList.clear();
        mList.addAll(list);
        this.notifyDataSetChanged();
    }

    public void updateDataFrist(List<M> list) {
        if (this.mList.addAll(list)) {
            notifyItemRangeInserted(0, list.size());
        }
    }

    public void updateDataLast(List<M> list) {
        int lastIndex = this.mList.size();
        if (this.mList.addAll(list)) {
            notifyItemRangeInserted(lastIndex, list.size());
        }

    }

    public void clear() {
        mList.clear();
        notifyDataSetChanged();
    }


}
