package com.wuzhanglong.library.activity;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;

import com.ashokvarma.bottomnavigation.BottomNavigationBar;
import com.wuzhanglong.library.R;
import com.wuzhanglong.library.fragment.BaseFragment;
import com.wuzhanglong.library.http.HttpClientUtil;
import com.wuzhanglong.library.mode.BaseVO;

import java.util.ArrayList;

public abstract class HomeFragmentActivity extends BaseActivity {

    public ViewPager mVpHome;
    public BottomNavigationBar mBottomNavigationBar;
    public ArrayList<BaseFragment> mFragmentList = new ArrayList<>();
    private static int tabLayoutHeight;

    public abstract void initBottomBar();
    @Override
    public void baseSetContentView() {
        View.inflate(this, R.layout.activity_home_fragment, mBaseContentLayout);
    }


    @RequiresApi(api = Build.VERSION_CODES.GINGERBREAD)
    @Override
    public void initView() {
        mFragmentList = (ArrayList<BaseFragment>) this.getIntent().getSerializableExtra("fragment_list");

        mVpHome = (ViewPager) findViewById(R.id.vp_home);
        mVpHome.setOffscreenPageLimit(4);
        mBottomNavigationBar = (BottomNavigationBar) findViewById(R.id.bottom_navigation_bar);
        initBottomBar();

        mVpHome.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return mFragmentList.get(position);
            }

            @Override
            public int getCount() {
                return mFragmentList.size();
            }
        });

//        tabLayoutHeight=mBottomNavigationBar.getMeasuredHeight();
    }


    @Override
    public void bindViewsListener() {
//        EventBus.getDefault().register(this);

        mBottomNavigationBar.setTabSelectedListener(new BottomNavigationBar.OnTabSelectedListener() {
            @Override
            public void onTabSelected(int position) {
                mVpHome.setCurrentItem(position);
            }

            @Override
            public void onTabUnselected(int position) {
            }

            @Override
            public void onTabReselected(int position) {
            }
        });



        mVpHome.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
            }

            @Override
            public void onPageSelected(int position) {
                mBottomNavigationBar.selectTab(position);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    @Override
    public void getData() {
        HttpClientUtil.show(mThreadUtil);
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
//        EventBus.getDefault().unregister(this);
    }

//    /**
//     * 菜单显示隐藏动画
//     * @param showOrHide
//     */
//    private void startAnimation(boolean showOrHide){
//        final ViewGroup.LayoutParams layoutParams = mBottomNavigationBar.getLayoutParams();
//        ValueAnimator valueAnimator;
//        ObjectAnimator alpha;
//        if(!showOrHide){
//            valueAnimator = ValueAnimator.ofInt(tabLayoutHeight, 0);
//            alpha = ObjectAnimator.ofFloat(mBottomNavigationBar, "alpha", 1, 0);
//        }else{
//            valueAnimator = ValueAnimator.ofInt(0, tabLayoutHeight);
//            alpha = ObjectAnimator.ofFloat(mBottomNavigationBar, "alpha", 0, 1);
//        }
//        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
//            @Override
//            public void onAnimationUpdate(ValueAnimator valueAnimator) {
//                layoutParams.height= (int) valueAnimator.getAnimatedValue();
//                mBottomNavigationBar.setLayoutParams(layoutParams);
//            }
//        });
//        AnimatorSet animatorSet=new AnimatorSet();
//        animatorSet.setDuration(500);
//        animatorSet.playTogether(valueAnimator,alpha);
//        animatorSet.start();
//    }

//    @Subscribe
//    public void onEventMainThread(EBMessageVO event) {
//        if ("hide_tab".equals(event.getMessage())) {
//            startAnimation(false);
//        }else {
//            startAnimation(true);
//        }
//    }


    @Override
    public boolean supportSlideBack() {
        return false;
    }
}
