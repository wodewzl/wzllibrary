
package com.wuzhanglong.library.interfaces;

public interface LoadMoreListener {
    public abstract void loadMore();
}
