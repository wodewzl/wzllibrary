package com.wuzhanglong.baselibrary.mode;

/**
 * Created by Administrator on 2017/2/25.
 */

public class EBMessageVO {
    public  String message;
    public EBMessageVO(String message) {
        this.message=message;
    }

    public String getMessage() {
        return message;
    }
}
