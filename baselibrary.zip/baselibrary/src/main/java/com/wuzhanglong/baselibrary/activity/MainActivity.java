package com.wuzhanglong.baselibrary.activity;


import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Toast;

import com.loopj.android.http.RequestParams;
import com.wuzhanglong.baselibrary.R;
import com.wuzhanglong.baselibrary.constant.BaseConstant;
import com.wuzhanglong.baselibrary.database.CacheDbHelper;
import com.wuzhanglong.baselibrary.http.HttpClientUtil;
import com.wuzhanglong.baselibrary.mode.BaseVO;
import com.wuzhanglong.baselibrary.mode.CrmOptionsVO;
import com.wuzhanglong.baselibrary.mode.EBMessageVO;

import org.greenrobot.eventbus.EventBus;
import org.greenrobot.eventbus.Subscribe;

public class MainActivity extends BaseActivity {
    private CacheDbHelper mDbHelper;
    CrmOptionsVO mCrmOptionsVO;
    // HashMap<String, String> mparamsMap = new HashMap<String, String>();
    RequestParams mparamsMap = new RequestParams();
    private EventBus aDefault;

    @Override
    public void baseSetContentView() {
        View.inflate(this, R.layout.base_main_activity, mBaseContentLayout);
    }

    @Override
    public void initView() {
        mDbHelper = new CacheDbHelper(this);
        initData();
    }

    @Override
    public void bindViewsListener() {

        this.findViewById(R.id.tv).setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View arg0) {
                HttpClientUtil.get(MainActivity.this, MainActivity.this, mUrl, mparamsMap,
                        CrmOptionsVO.class);
            }
        });
        EventBus.getDefault().register(this);
    }

    public void initData() {
        mparamsMap.put("userid", "49");
        mparamsMap.put("ftoken", "RBDTZXGUMNDKkEwMkZFN0UyMTA1RgO0O0OO0O0O");
        mUrl = "http://cp.beisheng.wang/dev_1.2.5/" + BaseConstant.CRM_CLIENT_OPTION;
        // String jsonOld = getCacheFromDatabase(mUrl, mparamsMap);
        // setCacheStrTime(mUrl, mparamsMap, value, time)
        // String jsonOld = getCacheStr(mUrl, mparamsMap);
        // mCrmOptionsVO = mGson.fromJson(jsonOld, CrmOptionsVO.class);
        // if (mCrmOptionsVO != null && "200".equals(mCrmOptionsVO.getCode())) {
        // executeSuccess();
        // }
    }


    @Override
    public void getData() {
        HttpClientUtil.get(this, this, mUrl, mparamsMap, CrmOptionsVO.class);
    }

    @Override
    public void hasData(BaseVO baseVO) {
        CrmOptionsVO vo = (CrmOptionsVO) baseVO;
        System.out.println("==========>1");
    }

    @Override
    public void noData(BaseVO baseVO) {
        System.out.println("==========>2");
    }

    @Override
    public void noNet() {

    }

    @Subscribe
    public void onEventMainThread(EBMessageVO event) {

        String msg = "onEventMainThread收到了消息：" + event.getMessage();
        Log.d("harvic", msg);

        Toast.makeText(this, msg, Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        EventBus.getDefault().unregister(this);
    }

}
