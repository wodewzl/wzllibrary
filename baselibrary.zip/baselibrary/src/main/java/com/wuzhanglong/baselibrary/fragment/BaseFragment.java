
package com.wuzhanglong.baselibrary.fragment;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.nostra13.universalimageloader.core.DisplayImageOptions;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.wuzhanglong.baselibrary.activity.BaseActivity;
import com.wuzhanglong.baselibrary.database.CacheDbHelper;
import com.wuzhanglong.baselibrary.interfaces.UpdateCallback;
import com.wuzhanglong.baselibrary.mode.BaseVO;

public abstract class BaseFragment extends Fragment implements UpdateCallback{
    public abstract void getData();

    public abstract void baseHasData(BaseVO vo);

    public abstract void baseNoData(BaseVO vo);

    public abstract void baseNoNet();

//    public abstract void initViews();

    private CacheDbHelper mDbHelper;
    private ImageLoader mImageLoader;
    private DisplayImageOptions mOptions;
    public BaseActivity mActivity;

    public abstract String getFragmentName();

    public BaseActivity getMyActivity() {
        return (BaseActivity) getActivity();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        this.mActivity = (BaseActivity) activity;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
//        initViews();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        getData();
    }


    @Override
    public void onStart() {
        super.onStart();
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    @Override
    public void onPause() {
        super.onPause();
//        MobclickAgent.onPageEnd(getFragmentName());
    }

    @Override
    public void onResume() {
        super.onResume();
//        MobclickAgent.onPageStart(getFragmentName());
    }

    public void hasData(BaseVO vo) {
        mActivity.dismissProgressDialog();
        mActivity.mBaseContentLayout.setVisibility(View.VISIBLE);
        baseHasData(vo);
    }

    public void noData(BaseVO vo) {
        mActivity.dismissProgressDialog();
        mActivity.mBaseContentLayout.setVisibility(View.GONE);
        mActivity.mNoContentTv.setVisibility(View.VISIBLE);
        baseNoData(vo);
    }

    public void noNet() {
        mActivity.dismissProgressDialog();
        mActivity.mBaseContentLayout.setVisibility(View.GONE);
        mActivity.mNoNetTv.setVisibility(View.VISIBLE);
        baseNoNet();
    }

    public void showView() {
        mActivity.dismissProgressDialog();
        mActivity.mBaseContentLayout.setVisibility(View.VISIBLE);
    }

}
