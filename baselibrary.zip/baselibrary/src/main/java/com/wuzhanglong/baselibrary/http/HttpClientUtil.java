package com.wuzhanglong.baselibrary.http;


import android.content.Context;
import android.util.Log;

import com.google.gson.Gson;
import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.RequestParams;
import com.wuzhanglong.baselibrary.activity.BaseActivity;
import com.wuzhanglong.baselibrary.cache.ACache;
import com.wuzhanglong.baselibrary.constant.BaseConstant;
import com.wuzhanglong.baselibrary.fragment.BaseFragment;
import com.wuzhanglong.baselibrary.interfaces.UpdateCallback;
import com.wuzhanglong.baselibrary.mode.BaseVO;
import com.wuzhanglong.baselibrary.utils.StringUtils;

import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

public class HttpClientUtil {
	private static AsyncHttpClient client = new AsyncHttpClient();

	public static <T> void get(final Context context, final UpdateCallback callback, final String url, final RequestParams params, final Class<T> className) {
		 if (url == null){
			 callback.baseHasData(null);
			 return;
		 }
		final Gson gson = new Gson();
		final String cacheStr = ACache.get(context).getAsString(url + params.toString());
		final BaseVO vo = (BaseVO) gson.fromJson(cacheStr, className);
//		&& BaseConstant.RESULT_FAIL_CODE400.equals(vo.getCode())
		if (vo != null) {
			callback.baseHasData(vo);
		}

		client.get(url, params, new AsyncHttpResponseHandler() {
			@Override
			public void onSuccess(int arg0, Header[] arg1, byte[] arg2) {
				String result = new String(arg2);
				if(result.equals(cacheStr)){
					return;
				}
				BaseVO vo = (BaseVO) gson.fromJson(result, className);
				if (BaseConstant.RESULT_FAIL_CODE400.equals(vo.getCode())) {
					callback.baseNoData(vo);
				} else {
					callback.baseHasData(vo);
				}

				if (!StringUtils.isEmpty(result)) {
					ACache.get(context).put(url + params.toString(), result, 60*60*24);
				}
				Log.i("get_url", (url + params.toString()).replaceAll("=","/").replaceAll("&","/"));
			}

			@Override
			public void onFailure(int arg0, Header[] arg1, byte[] arg2, Throwable arg3) {
				callback.baseNoNet();
			}
		});

	}

	public static <T> void get(final BaseFragment fragment, final String url, final RequestParams params, final Class<T> className) {
		final BaseActivity activity=fragment.mActivity;
		if (url == null){
			fragment.hasData(null);
			return;
		}
		final Gson gson = new Gson();
		final String cacheStr = ACache.get(activity).getAsString(url + params.toString());
		final BaseVO vo = (BaseVO) gson.fromJson(cacheStr, className);
//		&& BaseConstant.RESULT_FAIL_CODE400.equals(vo.getCode())
		if (vo != null) {
			fragment.hasData(vo);
		}

		client.get(url, params, new AsyncHttpResponseHandler() {
			@Override
			public void onSuccess(int arg0, Header[] arg1, byte[] arg2) {
				String result = new String(arg2);
				if( result.equals(cacheStr)){
					return;
				}
				BaseVO vo = (BaseVO) gson.fromJson(result, className);
				if (BaseConstant.RESULT_FAIL_CODE400.equals(vo.getCode())) {
					fragment.noData(vo);
				} else {
					fragment.hasData(vo);
				}

				if (!StringUtils.isEmpty(result)) {
					ACache.get(activity).put(url + params.toString(), result, 60*60*24);
				}
				Log.i("get_url", url + params.toString());
			}

			@Override
			public void onFailure(int arg0, Header[] arg1, byte[] arg2, Throwable arg3) {
				fragment.noNet();
			}
		});

	}

	public static void post(final Context context, String url, RequestParams params) {
		client.post(url, params, new AsyncHttpResponseHandler() {
			final BaseActivity activity = (BaseActivity) context;

			@Override
			public void onSuccess(int arg0, Header[] arg1, byte[] arg2) {
				try {
					String result = new String(arg2);
					JSONObject jsonObject = new JSONObject(new String(arg2));
					String str = (String) jsonObject.get("retinfo");
					String code = (String) jsonObject.get("code");
					if (BaseConstant.RESULT_FAIL_CODE400.equals(code)) {
						// activity.noData(vo);
					} else {
						// activity.hasData(vo);
					}
				} catch (Exception e) {
				}

			}

			@Override
			public void onFailure(int arg0, Header[] arg1, byte[] arg2, Throwable arg3) {
				System.out.println("================dddd");
			}
		});
	}

}
