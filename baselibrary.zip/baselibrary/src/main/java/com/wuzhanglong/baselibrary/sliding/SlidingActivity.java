
package com.wuzhanglong.baselibrary.sliding;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;

import com.nineoldandroids.view.ViewHelper;
import com.wuzhanglong.baselibrary.R;


/**
 * Created by chenjishi on 14-3-17.
 */
public class SlidingActivity extends AppCompatActivity {
    private static final float MIN_SCALE = 0.85f;

    private View mPreview;

    private float mInitOffset;
    private boolean hideTitle = false;
    private int titleResId = -1;
    Bitmap bmp;
    public SlidingLayout mSlidingLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.base_slide_layout);
        try {
            // 透明状态栏 4.4以后才可以显示
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
            // 透明导航栏
            // getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
        } catch (Exception e) {
            e.printStackTrace();
        }

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
//            //透明状态栏
//            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//            //透明导航栏
////            getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
//            SystemBarTintManager tintManager = new SystemBarTintManager(this);
//            // 激活状态栏
//            tintManager.setStatusBarTintEnabled(true);
//            // enable navigation bar tint 激活导航栏
////            tintManager.setNavigationBarTintEnabled(true);
//            //设置系统栏设置颜色
//            //tintManager.setTintColor(R.color.red);
//            //给状态栏设置颜色
//            tintManager.setStatusBarTintResource(R.color.sy_title_color);
//            //Apply the specified drawable or color resource to the system navigation bar.
//            //给导航栏设置资源
////            tintManager.setNavigationBarTintResource(R.color.mask_tags_1);
//        }


        // SDK在统计Fragment时，需要关闭Activity自带的页面统计，
        // 然后在每个页面中重新集成页面统计的代码(包括调用了 onResume 和 onPause 的Activity)。
        // MobclickAgent.openActivityDurationTrack(false);
    }


    @SuppressLint("NewApi")
    public void addContentView(int layoutResID) {

        DisplayMetrics metrics = getResources().getDisplayMetrics();
        LayoutInflater inflater = (LayoutInflater) getSystemService(Context
                .LAYOUT_INFLATER_SERVICE);
        mInitOffset = (1 - MIN_SCALE) * metrics.widthPixels / 2.f;

        mPreview = findViewById(R.id.iv_preview);
        FrameLayout contentView = (FrameLayout) findViewById(R.id.content_view);

        hideTitle = true;
        FrameLayout.LayoutParams layoutParams = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT, Gravity.BOTTOM);
        final int marginTop;
        if (hideTitle) {
            marginTop = 0;
        } else {
            marginTop = (int) (metrics.density * 48.f + .5f);
        }
        layoutParams.setMargins(0, marginTop, 0, 0);
        contentView.addView(inflater.inflate(layoutResID, null), layoutParams);

        mSlidingLayout = (SlidingLayout) findViewById(R.id.slide_layout);
        mSlidingLayout.setShadowResource(R.drawable.base_sliding_back_shadow);
        mSlidingLayout.setSliderFadeColor(0x00000000);
        mSlidingLayout.setPanelSlideListener(new SlidingLayout.SimpleSlideListener() {
            @Override
            public void onPanelSlide(View panel, float slideOffset) {
                final int sdkInt = Build.VERSION.SDK_INT;

                if (slideOffset <= 0) {
                    if (sdkInt >= Build.VERSION_CODES.HONEYCOMB) {
                        mPreview.setScaleX(MIN_SCALE);
                        mPreview.setScaleY(MIN_SCALE);
                    } else {
                        ViewHelper.setScaleX(mPreview, MIN_SCALE);
                        ViewHelper.setScaleY(mPreview, MIN_SCALE);
                    }
                } else if (slideOffset < 1) {
                    // Scale the page down (between MIN_SCALE and 1)
                    float scaleFactor = MIN_SCALE + Math.abs(slideOffset) * (1 - MIN_SCALE);

                    if (sdkInt >= Build.VERSION_CODES.HONEYCOMB) {
                        mPreview.setAlpha(slideOffset);
                        mPreview.setTranslationX(mInitOffset * (1 - slideOffset));
                        mPreview.setScaleX(scaleFactor);
                        mPreview.setScaleY(scaleFactor);
                    } else {
                        ViewHelper.setAlpha(mPreview, slideOffset);
                        ViewHelper.setTranslationX(mPreview, mInitOffset * (1 - slideOffset));
                        ViewHelper.setScaleX(mPreview, scaleFactor);
                        ViewHelper.setScaleY(mPreview, scaleFactor);
                    }
                } else {
                    if (sdkInt >= Build.VERSION_CODES.HONEYCOMB) {
                        mPreview.setScaleX(1);
                        mPreview.setScaleY(1);
                        mPreview.setAlpha(1);
                        mPreview.setTranslationX(0);
                    } else {
                        ViewHelper.setScaleX(mPreview, 1);
                        ViewHelper.setScaleY(mPreview, 1);
                        ViewHelper.setAlpha(mPreview, 1);
                        ViewHelper.setTranslationX(mPreview, 0);

                    }
                    finish();
                    overridePendingTransition(0, 0);
                }
            }
        });

        byte[] byteArray = getIntent().getByteArrayExtra(IntentUtils.KEY_PREVIEW_IMAGE);
        if (null != byteArray && byteArray.length > 0) {
            try {
                bmp = BitmapFactory.decodeByteArray(byteArray, 0, byteArray.length);
                if (null != bmp) {
                    ((ImageView) mPreview).setImageBitmap(bmp);
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                        mPreview.setScaleX(MIN_SCALE);
                        mPreview.setScaleY(MIN_SCALE);
                    } else {
                        ViewHelper.setScaleX(mPreview, MIN_SCALE);
                        ViewHelper.setScaleY(mPreview, MIN_SCALE);
                    }
                } else {
                    /** preview image captured fail, disable the slide back */
                    mSlidingLayout.setSlideable(false);
                }
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (null != bmp && !bmp.isRecycled()) {
                    // bmp.recycle();
                    bmp = null;
                }
            }
        } else {
            /** preview image captured fail, disable the slide back */
            mSlidingLayout.setSlideable(false);
        }
    }

    protected void setContentView(int layoutResID, int titleResId) {
        this.titleResId = titleResId;
        setContentView(layoutResID);
    }

    protected void setContentView(int layoutResID, boolean hideTitle) {
        this.hideTitle = hideTitle;
        setContentView(layoutResID);
    }

    public void onResume() {
        super.onResume();
//        MobclickAgent.onResume(this); // 统计时长
    }

    public void onPause() {
        super.onPause();
//        MobclickAgent.onPause(this);
    }

}
