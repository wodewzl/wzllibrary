package com.wuzhanglong.baselibrary.interfaces;

import com.wuzhanglong.baselibrary.mode.BaseVO;

public interface UpdateCallback {


//	public abstract void executeSuccess();
//
//	public abstract void executeFailure();

	public abstract void baseHasData(BaseVO v) ;

	public abstract void baseNoData(BaseVO vo) ;

	public abstract  void baseNoNet() ;
}
