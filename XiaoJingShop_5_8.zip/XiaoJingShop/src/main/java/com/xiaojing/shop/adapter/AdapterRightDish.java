package com.xiaojing.shop.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;
import com.wuzhanglong.library.adapter.RecyclerBaseAdapter;
import com.xiaojing.shop.R;
import com.xiaojing.shop.mode.CategoryVO;

import cn.bingoogolapple.androidcommon.adapter.BGAViewHolderHelper;

/**
 * Created by cheng on 16-11-10.
 */
public class AdapterRightDish extends RecyclerBaseAdapter<CategoryVO> {
    public AdapterRightDish(RecyclerView recyclerView) {
        super(recyclerView, R.layout.right_menu_item);
    }

    @Override
    public void initData(BGAViewHolderHelper helper, int position, Object model) {
        CategoryVO vo= (CategoryVO) model;
        if(vo.getGrandson() !=null){
            helper.setText(R.id.right_menu_tv,vo.getGc_name());
//            LinearLayout right_menu_item =helper.getView(R.id.right_menu_item);
           View view= helper.getConvertView();
            view.setContentDescription(position+"");
        }else{
            helper.setText(R.id.child_itme,vo.getGc_name());
            ImageView img=helper.getImageView(R.id.img);
                Picasso.with(mContext).load(vo.getGc_image()).into(img);
        }

    }

    @Override
    public int getItemViewType(int position) {
        CategoryVO vo= (CategoryVO) mData.get(position);
        if(vo.getGrandson() !=null){
            return R.layout.right_menu_item;
        }else{
            return R.layout.right_dish_item1;
        }
    }

//
//public class AdapterRightDish extends LRecyclerBaseAdapter<CategoryVO> implements
//        StickyHeaderAdapter<AdapterRightDish.HeaderHolder>{
//
//    private LayoutInflater mInflater;
//    private Context mContext;
//
//    public AdapterRightDish(Context context) {
//        mContext = context;
//        mInflater = LayoutInflater.from(context);
//    }
//
//    @Override
//    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
//        final View view = mInflater.inflate(R.layout.right_dish_item1, viewGroup, false);
//        return new ViewHolder(view);
//    }
//
//    @Override
//    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
//        super.onBindViewHolder(holder, position);
////        ViewHolder viewHolder= (ViewHolder) holder;
////        viewHolder.child_itme.setText(mList.get(position).getGc_name());
////        Picasso.with(mContext).load(mList.get(position).getGc_image()).into(viewHolder.img);
//    }
//
//    @Override
//    public long getHeaderId(int position) {
//        //原理是这样的 11112222333334444444 同样字段是一组
//        if(position>=mList.size()){
//            return Integer.parseInt(mList.get(mList.size()-1).getParent_id());
//        }else {
//            return Integer.parseInt(mList.get(position).getParent_id());
//        }
//
//    }
//
////    @Override
////    public int getItemCount() {
////        return 15;
////    }
//
//    @Override
//    public HeaderHolder onCreateHeaderViewHolder(ViewGroup parent) {
//        final View view = mInflater.inflate(R.layout.right_menu_item, parent, false);
//        return new HeaderHolder(view);
//    }
//
//    @Override
//    public void onBindHeaderViewHolder(final HeaderHolder viewholder, final int position) {
////        viewholder.header.setText("Header " + getHeaderId(position));
////        viewholder.itemView.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View view) {
////                Toast.makeText(mContext, "onBindHeaderViewHolder item clicked position = " + position, Toast.LENGTH_SHORT).show();
////            }
////        });
////        if (getHeaderId(position) == 2) {
////            viewholder.header.setVisibility(View.GONE);
////        } else {
////            viewholder.header.setVisibility(View.VISIBLE);
////
////        }
//        viewholder.right_menu_tv.setText(mList.get(position).getParent_name());
//    }
//
//
//    static class ViewHolder extends RecyclerView.ViewHolder {
//        public TextView child_itme;
//        public ImageView img;
//
//        public ViewHolder(View itemView) {
//            super(itemView);
////            item = (TextView) itemView;
//            child_itme= (TextView) itemView.findViewById(R.id.child_itme);
//            img= (ImageView) itemView.findViewById(R.id.img);
//        }
//    }
//
//    static class HeaderHolder extends RecyclerView.ViewHolder {
//        public TextView right_menu_tv;
//
//        public HeaderHolder(View itemView) {
//            super(itemView);
//            right_menu_tv = (TextView) itemView.findViewById(R.id.right_menu_tv);
//        }
//    }
}
