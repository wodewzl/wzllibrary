package com.xiaojing.shop.activity;

import android.content.Intent;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.view.View;

import com.ashokvarma.bottomnavigation.BottomNavigationItem;
import com.wuzhanglong.library.activity.BaseHomeActivity;
import com.xiaojing.shop.R;

import pub.devrel.easypermissions.EasyPermissions;

import static com.ashokvarma.bottomnavigation.BottomNavigationBar.BACKGROUND_STYLE_STATIC;
import static com.ashokvarma.bottomnavigation.BottomNavigationBar.MODE_SHIFTING;

/**
 * Created by Administrator on 2017/3/10.
 */
//HomeFragmentActivity
public class HomeActivity extends BaseHomeActivity {

    @RequiresApi(api = Build.VERSION_CODES.GINGERBREAD)
    @Override
    public void initBottomBar() {
//        int[] drawableIds = new int[] {R.drawable.home_01, R.drawable.home_01, R.drawable.home_01, R.drawable.home_01};
//        mTabWidget.update(this,drawableIds);
//        onTabSelected(0);

//        MODE_FIXED+BACKGROUND_STYLE_STATIC
//        MODE_FIXED+BACKGROUND_STYLE_RIPPLE
//        MODE_SHIFTING+BACKGROUND_STYLE_STATIC
//        MODE_SHIFTING+BACKGROUND_STYLE_RIPPLE
        mBottomNavigationBar.setMode(MODE_SHIFTING);
        mBottomNavigationBar.setBackgroundStyle(BACKGROUND_STYLE_STATIC);

        mBottomNavigationBar
                .setActiveColor(R.color.C7)
                .setInActiveColor(R.color.sy_title_color)
                .setBarBackgroundColor(R.color.C1);

        mBottomNavigationBar.addItem(new BottomNavigationItem(R.drawable.ic_home_black_48dp, "首页"))
                .addItem(new BottomNavigationItem(R.drawable.ic_format_list_bulleted_white_48dp, "分类"))
                .addItem(new BottomNavigationItem(R.drawable.ic_add_shopping_cart_black_48dp, "购物车"))
                .addItem(new BottomNavigationItem(R.drawable.ic_perm_identity_black_48dp, "个人中心"))
                .setFirstSelectedPosition(0)
                .initialise();
        mBottomNavigationBar.selectTab(0);
        mBaseHeadLayout.setVisibility(View.GONE);
    }


    public void initPermissions(){
        String[] perms = {android.Manifest.permission.ACCESS_COARSE_LOCATION, android.Manifest.permission.ACCESS_FINE_LOCATION,android.Manifest.permission.WRITE_EXTERNAL_STORAGE};
        if (EasyPermissions.hasPermissions(this, perms)) {
            // 县市定位
//            mLocationClient = new LocationClient(MainActivity.this.getApplicationContext()); // 声明LocationClient类
//            mLocationClient.registerLocationListener(myListener); // 注册监听函数
//            initLocation();
//            mLocationClient.start();
        } else {
            EasyPermissions.requestPermissions(this, "定位需要需要权限", 1, perms);
        }

    }

    @Override
    protected void onActivityResult(int arg0, int arg1, Intent arg2) {
        super.onActivityResult(arg0, arg1, arg2);
        if (mFragmentList.get(3) != null && mFragmentList.get(3).isVisible()) {
			/* 然后在碎片中调用重写的onActivityResult方法 */
            mFragmentList.get(3).onActivityResult(arg0, arg1, arg2);
        }
    }
}
