package com.xiaojing.shop.activity;

import android.annotation.TargetApi;
import android.os.Build;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.github.jdsjlzx.recyclerview.LuRecyclerView;
import com.github.jdsjlzx.recyclerview.LuRecyclerViewAdapter;
import com.loopj.android.http.RequestParams;
import com.rey.material.widget.TextView;
import com.wuzhanglong.library.ItemDecoration.DividerDecoration;
import com.wuzhanglong.library.ItemDecoration.StickyHeaderDecoration;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.http.HttpClientUtil;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.BaseCommonUtils;
import com.wuzhanglong.library.utils.DividerUtil;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.MyOverAdapter;
import com.xiaojing.shop.application.AppApplication;
import com.xiaojing.shop.constant.Constant;
import com.xiaojing.shop.mode.MoneyVO;

public class MyOverActivity extends BaseActivity {
    private TextView mWithdrawTv,mRechargeTv;
    private LuRecyclerView mRecyclerView;
    private MyOverAdapter mAdapter;
    private StickyHeaderDecoration decor;
    private LuRecyclerViewAdapter mLuAdapter;
    private MoneyVO mMoneyVO;
    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.my_over_activity);
    }

    @Override
    public void initView() {
        mRecyclerView = getViewById(R.id.recycler_view);
//        mRecyclerView.setPullRefreshEnabled(false);
        DividerDecoration divider = DividerUtil.linnerDivider(this,R.dimen.dp_1,R.color.C3);
        mRecyclerView.addItemDecoration(divider);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mAdapter = new MyOverAdapter(this);
        mLuAdapter = new LuRecyclerViewAdapter(mAdapter);

//        CommonHeader headerView = new CommonHeader(this, R.layout.my_jingbi_head);

        mLuAdapter.addHeaderView(initHeadView());
        decor = new StickyHeaderDecoration(mAdapter);
        mRecyclerView.setAdapter(mLuAdapter);
        mRecyclerView.addItemDecoration(decor, 1);
    }

    @Override
    public void bindViewsListener() {

    }

    @Override
    public BaseVO getData() {
        RequestParams paramsMap = new RequestParams();
        String mUrl = Constant.MY_OVER_URL;
        paramsMap.put("key", AppApplication.getInstance().getUserInfoVO().getKey());
        return HttpClientUtil.getRequest(mActivity, this, mUrl, paramsMap, MoneyVO.class);

    }

    @Override
    public void hasData(BaseVO vo) {
        MoneyVO moneyVO= (MoneyVO) vo;
        mMoneyVO=moneyVO.getDatas();
        mAdapter.updateData(mMoneyVO.getList());
    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public View  initHeadView(){
        View header = LayoutInflater.from(this).inflate(R.layout.my_over_head,(ViewGroup)findViewById(android.R.id.content), false);

        mRechargeTv = (TextView) header.findViewById(R.id.recharge_tv);
        mWithdrawTv= (TextView) header.findViewById(R.id.withdraw_tv);

        mRechargeTv.setBackground(BaseCommonUtils.setBackgroundShap(this,50,R.color.XJColor6,R.color.C1));
        mWithdrawTv.setBackground(BaseCommonUtils.setBackgroundShap(this,100,R.color.XJColor6,R.color.C1));


        return header;
    }

}
