package com.xiaojing.shop.fragment;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import com.lzy.widget.HeaderScrollHelper;
import com.wuzhanglong.library.ItemDecoration.DividerDecoration;
import com.wuzhanglong.library.fragment.BaseFragment;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.DividerUtil;
import com.wuzhanglong.library.view.AutoSwipeRefreshLayout;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.OneShopRAdapter1;

public  class OneShopFragment extends BaseFragment implements HeaderScrollHelper.ScrollableContainer{
    private AutoSwipeRefreshLayout mAutoSwipeRefreshLayout;
    private RecyclerView mRecyclerView;
    private OneShopRAdapter1 mAdapter;
    public static OneShopFragment newInstance() {
        OneShopFragment fragment = new OneShopFragment();
        return fragment;
    }
    @Override
    public View getScrollableView() {
        return mRecyclerView;
    }

    @Override
    public BaseVO getData() {
        return null;
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    @Override
    public void setContentView() {
        contentInflateView(R.layout.one_shop_order_fragment);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void initView(View view) {
        mRecyclerView=getViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(new GridLayoutManager(mActivity,2));
        mAdapter= new OneShopRAdapter1(mRecyclerView);
        mRecyclerView.setAdapter(mAdapter);
        DividerDecoration divider = DividerUtil.linnerDivider(mActivity, R.dimen.dp_1, R.color.C3);
        mRecyclerView.addItemDecoration(divider);

    }

    @Override
    public void bindViewsListener() {

    }


}
