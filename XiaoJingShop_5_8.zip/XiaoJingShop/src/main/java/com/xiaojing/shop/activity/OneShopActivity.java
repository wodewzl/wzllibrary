package com.xiaojing.shop.activity;

import android.content.Context;
import android.graphics.Color;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.LinearLayout;

import com.github.jdsjlzx.recyclerview.LuRecyclerView;
import com.lzy.widget.HeaderViewPager;
import com.vondear.rxtools.view.RxTextviewVertical;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.view.ScaleTransitionPagerTitleView;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.OneShopRAdapter;
import com.xiaojing.shop.fragment.OneShopFragment;

import net.lucode.hackware.magicindicator.MagicIndicator;
import net.lucode.hackware.magicindicator.ViewPagerHelper;
import net.lucode.hackware.magicindicator.buildins.UIUtil;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;

import java.util.ArrayList;

public class OneShopActivity extends BaseActivity {
    private String[] mTitleDataList={"人气","进度","最新揭晓"};
    private ViewPager mViewPager;
    private ArrayList<OneShopFragment> mFragmentList;
    private LuRecyclerView mRecyclerView;
    private OneShopRAdapter mAdapter;
    private RxTextviewVertical mRxText;
    private HeaderViewPager scrollableLayout;
    private LinearLayout mHeadLayout;
    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.one_shop_activity);
    }

    @Override
    public void initView() {
        scrollableLayout = (HeaderViewPager) findViewById(R.id.scrollableLayout);
        mHeadLayout=getViewById(R.id.head_layout);
//        PagerSlidingTabStrip tabs = (PagerSlidingTabStrip) findViewById(R.id.tabs);

        mViewPager=getViewById(R.id.view_pager);
//        initViewPagerData();
//        tabs.setViewPager(mViewPager);
        initMagicIndicator();
        scrollableLayout.setCurrentScrollableContainer(mFragmentList.get(0));
        mViewPager.addOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
            @Override
            public void onPageSelected(int position) {
                scrollableLayout.setCurrentScrollableContainer(mFragmentList.get(position));
            }
        });

        scrollableLayout.setOnScrollListener(new HeaderViewPager.OnScrollListener() {
            @Override
            public void onScroll(int currentY, int maxY) {
                mHeadLayout.setTranslationY(currentY / 2);
            }
        });
//        mViewPager.setCurrentItem(0);

//        initMagicIndicator();
//        mViewPager.setOnTouchListener(new View.OnTouchListener() {
//            @Override
//            public boolean onTouch(View view, MotionEvent motionEvent) {
//                view.getParent().requestDisallowInterceptTouchEvent(false);
//                return false;
//            }
//        });

//
//        mRecyclerView = getViewById(R.id.recycler_view);
//        mRecyclerView.setLayoutManager(new LinearLayoutManager(mActivity));
//        mAdapter = new OneShopRAdapter(mRecyclerView);
//        LuRecyclerViewAdapter adapter = new LuRecyclerViewAdapter(mAdapter);
//        mRecyclerView.setAdapter(adapter);
//        DividerDecoration divider = DividerUtil.linnerDivider(this,R.dimen.dp_1,R.color.C3);
//        mRecyclerView.addItemDecoration(divider);
//        mRecyclerView.setLoadingMoreProgressStyle(ProgressStyle.BallSpinFadeLoader);
//        mRecyclerView.setLoadMoreEnabled(true);

//        ArrayList list= new ArrayList();
//        list.add(new HomeVO());
//        list.add(new HomeVO());
//        list.add(new HomeVO());
//        mAdapter.updateData(list);


//        mRxText = (RxTextviewVertical) findViewById(R.id.rx_text);
//        ArrayList<String> list = new ArrayList<>();
//        list.add("你是天上最受宠的一架钢琴");
//        list.add("我是丑人脸上的鼻涕");
//        list.add("你发出完美的声音");
//        list.add("我被默默揩去");
//        list.add("你冷酷外表下藏着诗情画意");
//        list.add("我已经够胖还吃东西");
//        list.add("你踏着七彩祥云离去");
//        list.add("我被留在这里");
//        mRxText.setTextList(list);
//        mRxText.setText(14, 5, 0xff766156);//设置属性
//        mRxText.setTextStillTime(3000);//设置停留时长间隔
//        mRxText.setAnimTime(300);//设置进入和退出的时间间隔
//        mRxText.setOnItemClickListener(new RxTextviewVertical.OnItemClickListener() {
//            @Override
//            public void onItemClick(int position) {
//               OneShopActivity.this.showCustomToast("..........................");
//            }
//        });
    }

    private void initMagicIndicator() {
        MagicIndicator magicIndicator = (MagicIndicator) findViewById(R.id.magic_indicator);
        magicIndicator.setBackgroundColor(Color.WHITE);
        CommonNavigator commonNavigator = new CommonNavigator(this);
        commonNavigator.setAdjustMode(true);
        commonNavigator.setAdapter(new CommonNavigatorAdapter() {
            @Override
            public int getCount() {
                return mTitleDataList == null ? 0 : mTitleDataList.length;
            }

            @Override
            public IPagerTitleView getTitleView(Context context, final int index) {
                SimplePagerTitleView simplePagerTitleView = new ScaleTransitionPagerTitleView(context);
                simplePagerTitleView.setText(mTitleDataList[index]);
                simplePagerTitleView.setTextSize(18);
                simplePagerTitleView.setNormalColor(Color.parseColor("#616161"));
                simplePagerTitleView.setSelectedColor(Color.parseColor("#f57c00"));
                simplePagerTitleView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mViewPager.setCurrentItem(index);
                    }
                });
                return simplePagerTitleView;
            }

            @Override
            public IPagerIndicator getIndicator(Context context) {
                LinePagerIndicator indicator = new LinePagerIndicator(context);
                indicator.setStartInterpolator(new AccelerateInterpolator());
                indicator.setEndInterpolator(new DecelerateInterpolator(1.6f));
//                indicator.setYOffset(UIUtil.dip2px(context, 39));
                indicator.setLineHeight(UIUtil.dip2px(context, 2));
                indicator.setColors(Color.parseColor("#f57c00"));
//                LinePagerIndicator indicator = new LinePagerIndicator(context);
//                indicator.setColors(Color.parseColor("#40c4ff"));
                return indicator;
            }

            @Override
            public float getTitleWeight(Context context, int index) {
                if (index == 0) {
                    return 1.0f;
                } else if (index == 1) {
                    return 1.0f;
                } else {
                    return 1.0f;
                }
            }
        });

        initViewPagerData();
        magicIndicator.setNavigator(commonNavigator);
        ViewPagerHelper.bind(magicIndicator, mViewPager);

    }

    public void initViewPagerData(){
        mFragmentList=new ArrayList<>();
        for (int i = 0; i <mTitleDataList.length ; i++) {
            mFragmentList.add(OneShopFragment.newInstance());
        }
        mViewPager.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return mFragmentList.get(position);
            }

            private String[] titles={"人气","进度","最新揭晓"};
            @Override
            public CharSequence getPageTitle(int position) {
                return titles[position];
            }
            @Override
            public int getCount() {
                return mFragmentList.size();
            }
        });

    }

    @Override
    public void bindViewsListener() {

    }

    @Override
    public BaseVO getData() {
        showView();
        return null;
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }
//    @Override
//    protected void onResume() {
//        super.onResume();
//        mRxText.startAutoScroll();
//    }
//
//    @Override
//    protected void onPause() {
//        super.onPause();
//        mRxText.stopAutoScroll();
//    }


}
