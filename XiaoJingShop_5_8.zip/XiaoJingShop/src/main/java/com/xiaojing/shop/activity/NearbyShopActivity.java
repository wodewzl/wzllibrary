package com.xiaojing.shop.activity;

import android.support.v7.widget.LinearLayoutManager;
import android.view.View;

import com.github.jdsjlzx.recyclerview.LuRecyclerView;
import com.github.jdsjlzx.recyclerview.LuRecyclerViewAdapter;
import com.rey.material.widget.TextView;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.DividerUtil;
import com.wuzhanglong.library.view.AutoSwipeRefreshLayout;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.NearbyShopRadapter;
import com.xiaojing.shop.mode.ShopVO;

public class NearbyShopActivity extends BaseActivity implements View.OnClickListener{
    private LuRecyclerView mLuRecyclerView;
    private AutoSwipeRefreshLayout mSwipeRefresh;
    private NearbyShopRadapter mAdapter;
    private TextView mPriceTv;

    private ShopVO mShopVO;


    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.nearby_shop_activity);
    }

    @Override
    public void initView() {
        mSwipeRefresh = getViewById(R.id.swipe_refresh_layout);
        mLuRecyclerView = getViewById(R.id.recycler_view);
        mLuRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mLuRecyclerView.addItemDecoration(DividerUtil.linnerDivider(this, R.dimen.dp_1, R.color.C3));
        mAdapter = new NearbyShopRadapter(mLuRecyclerView);
        LuRecyclerViewAdapter adapter = new LuRecyclerViewAdapter(mAdapter);
        mLuRecyclerView.setAdapter(adapter);

    }

    @Override
    public void bindViewsListener() {

    }

    @Override
    public BaseVO getData() {
//        RequestParams paramsMap = new RequestParams();
//        String mUrl = Constant.SHOP_LIST_URL;
//        paramsMap.put("key", AppApplication.getInstance().getUserInfoVO().getKey());
//        return HttpClientUtil.getRequest(mActivity, this, mUrl, paramsMap, ShopVO.class);
        return  null;
    }

    @Override
    public void hasData(BaseVO vo) {
//        ShopVO shopVO= (ShopVO) vo;
//        mShopVO=shopVO.getDatas();
//        mAdapter.updateData(mShopVO.getGoods_list());
    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    @Override
    public void onClick(View v) {

    }
}
