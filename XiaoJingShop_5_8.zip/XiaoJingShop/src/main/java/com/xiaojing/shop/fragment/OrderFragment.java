package com.xiaojing.shop.fragment;

import android.support.v7.widget.LinearLayoutManager;
import android.view.View;

import com.github.jdsjlzx.recyclerview.LuRecyclerView;
import com.github.jdsjlzx.recyclerview.LuRecyclerViewAdapter;
import com.wuzhanglong.library.fragment.BaseFragment;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.DividerUtil;
import com.wuzhanglong.library.view.AutoSwipeRefreshLayout;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.OrderRAdapter;

public class OrderFragment extends BaseFragment {
    private AutoSwipeRefreshLayout mAutoSwipeRefreshLayout;
    private LuRecyclerView mRecyclerView;
    private OrderRAdapter mOrderRAdapter;
    public static BaseFragment newInstance() {
        BaseFragment fragment = new OrderFragment();
        return fragment;
    }
    @Override
    public BaseVO getData() {
       return null;
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    @Override
    public void setContentView() {
        contentInflateView(R.layout.order_fragment);
    }

    @Override
    public void initView(View view) {

        mAutoSwipeRefreshLayout=getViewById(R.id.swipe_refresh_layout);
        mActivity.setSwipeRefreshLayoutColors(mAutoSwipeRefreshLayout);
        mRecyclerView=getViewById(R.id.recycler_view);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(mActivity));
        mOrderRAdapter= new OrderRAdapter(mRecyclerView);
        LuRecyclerViewAdapter adapter= new LuRecyclerViewAdapter(mOrderRAdapter);
        mRecyclerView.setAdapter(adapter);
        mRecyclerView.addItemDecoration(DividerUtil.linnerDivider(mActivity,R.dimen.dp_10,R.color.C3));
    }

    @Override
    public void bindViewsListener() {

    }
}
