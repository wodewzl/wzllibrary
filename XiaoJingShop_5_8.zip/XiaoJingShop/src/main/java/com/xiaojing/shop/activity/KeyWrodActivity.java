package com.xiaojing.shop.activity;

import android.widget.Toast;

import com.loopj.android.http.RequestParams;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.http.HttpClientUtil;
import com.wuzhanglong.library.mode.BaseVO;
import com.xiaojing.shop.R;
import com.xiaojing.shop.application.AppApplication;
import com.xiaojing.shop.constant.Constant;
import com.xiaojing.shop.mode.KeyWordVO;
import com.yang.flowlayoutlibrary.FlowLayout;

import java.util.Arrays;

public class KeyWrodActivity extends BaseActivity {
    private FlowLayout mFlowLayout;
    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.key_wrod_activity);
    }

    @Override
    public void initView() {
        mBaseTitleTv.setText("关键字");
        mFlowLayout = (FlowLayout) findViewById(R.id.fl_keyword);
    }

    @Override
    public void bindViewsListener() {

    }

    @Override
    public BaseVO getData() {
        RequestParams paramsMap = new RequestParams();
        String mUrl = Constant.KEYWORD_URL;
        paramsMap.put("key", AppApplication.getInstance().getUserInfoVO().getKey());
        return HttpClientUtil.getRequest(mActivity, this, mUrl, paramsMap, KeyWordVO.class);
    }

    @Override
    public void hasData(BaseVO vo) {
        KeyWordVO keyWordVO= (KeyWordVO) vo;
        mFlowLayout.setFlowLayout(Arrays.asList(((KeyWordVO) vo).getDatas().getList()), new FlowLayout.OnItemClickListener() {
            @Override
            public void onItemClick(String content) {
                Toast.makeText(KeyWrodActivity.this, content, Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }



}
