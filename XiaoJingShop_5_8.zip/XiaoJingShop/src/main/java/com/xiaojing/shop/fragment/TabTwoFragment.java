package com.xiaojing.shop.fragment;

import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.loopj.android.http.RequestParams;
import com.wuzhanglong.library.ItemDecoration.DividerDecoration;
import com.wuzhanglong.library.fragment.BaseFragment;
import com.wuzhanglong.library.http.HttpClientUtil;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.DividerUtil;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.AdapterLeftMenu;
import com.xiaojing.shop.adapter.AdapterRightDish;
import com.xiaojing.shop.constant.Constant;
import com.xiaojing.shop.mode.CategoryVO;

import java.util.ArrayList;
import java.util.List;


/**
 * Created by Administrator on 2017/2/9.
 */

public class TabTwoFragment extends BaseFragment  implements AdapterLeftMenu.OnLeftSelectedListener{
    private RecyclerView leftMenu;//左侧菜单栏
    private RecyclerView rightMenu;//右侧菜单栏
    private TextView headerView;
    private LinearLayout headerLayout;//右侧菜单栏最上面的菜单

    private CategoryVO headMenu;
    private AdapterLeftMenu leftAdapter;
    private AdapterRightDish rightAdapter;
    private List<CategoryVO> dishMenuList=new ArrayList<>();//数据源
    private boolean leftClickType = false;//左侧菜单点击引发的右侧联动
//    private ShopCart shopCart;
    //    private RxFakeAddImageView fakeAddImageView;

    private RelativeLayout mainLayout;
    private CategoryVO mCategoryVO;
    @Override
    public void setContentView() {
        View.inflate(mActivity, R.layout.tab_two_fragment,mBaseContentLayout);
    }

    @Override
    public void initView(View view) {
        mainLayout = (RelativeLayout)view.findViewById(R.id.main_layout);
        leftMenu = (RecyclerView)view.findViewById(R.id.left_menu);
        DividerDecoration divider = DividerUtil.linnerDivider(mActivity,R.dimen.dp_1,R.color.C3);
        leftMenu.addItemDecoration(divider);
        rightMenu = (RecyclerView)view.findViewById(R.id.right_menu);
        headerView = (TextView)view.findViewById(R.id.right_menu_tv);
        headerLayout = (LinearLayout)view.findViewById(R.id.right_menu_item);
//        fakeAddImageView = (RxFakeAddImageView)findViewById(R.id.right_dish_fake_add);

        leftMenu.setLayoutManager(new LinearLayoutManager(mActivity));
        GridLayoutManager mLayoutManager = new GridLayoutManager(mActivity, 3);
        rightMenu.setLayoutManager(mLayoutManager);

        mLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                switch (rightAdapter.getItemViewType(position)) {
                    case R.layout.right_menu_item:
                        return 3;
                    default:
                        return 1;
                }
            }
        });

        leftAdapter = new AdapterLeftMenu(leftMenu);


        rightAdapter = new AdapterRightDish(rightMenu);




        rightMenu.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);
            }
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                if( recyclerView.canScrollVertically(1)==false) {//无法下滑
                    showHeadView();
                    return;
                }
                View underView = null;
                if(dy>0)
                    underView = rightMenu.findChildViewUnder(headerLayout.getX(),headerLayout.getMeasuredHeight()+1);
                else
                    underView = rightMenu.findChildViewUnder(headerLayout.getX(),0);
                if(underView!=null && underView.getContentDescription()!=null ){
                    int position = Integer.parseInt(underView.getContentDescription().toString());
//                    CategoryVO menu = rightAdapter.getMenuOfMenuByPosition(position);
                    CategoryVO menu = dishMenuList.get(position);

                    if(leftClickType || !menu.getGc_name().equals(headMenu.getGc_name())) {
                        if (dy> 0 && headerLayout.getTranslationY()<=1 && headerLayout.getTranslationY()>= -1 * headerLayout.getMeasuredHeight()*4/5 && !leftClickType) {// underView.getTop()>9
                            int dealtY = underView.getTop() - headerLayout.getMeasuredHeight();
                            headerLayout.setTranslationY(dealtY);
                        }
                        else if(dy<0 && headerLayout.getTranslationY()<=0 && !leftClickType) {
                            headerView.setText(menu.getGc_name());
                            int dealtY = underView.getBottom() - headerLayout.getMeasuredHeight();
                            headerLayout.setTranslationY(dealtY);
                        }
                        else{
                            headerLayout.setTranslationY(0);
                            headMenu = menu;
                            headerView.setText(headMenu.getGc_name());
//                            for (int i = 0; i < mCategoryVO.getData().getCategories().size(); i++) {
//                                if (mCategoryVO.getData().getCategories().get(i) == headMenu) {
////                                    leftAdapter.setSelectedNum(i);
//                                    break;
//                                }
//                            }
                            if(leftClickType)leftClickType=false;

                        }
                    }
                }
            }
        });

    }

    private void initHeadView(){
//        headMenu = rightAdapter.getMenuOfMenuByPosition(0);
        headMenu=dishMenuList.get(0);
        headerLayout.setContentDescription("0");
        headerView.setText(headMenu.getGc_name());
    }

    private void showHeadView(){
        headerLayout.setTranslationY(0);
        View underView = rightMenu.findChildViewUnder(headerView.getX(),0);
        if(underView!=null && underView.getContentDescription()!=null){
            int position = Integer.parseInt(underView.getContentDescription().toString());
//            CategoryVO menu = rightAdapter.getMenuOfMenuByPosition(position+1);
            CategoryVO menu = dishMenuList.get(position+1);
            headMenu = menu;
            headerView.setText(headMenu.getGc_name());
            for (int i = 0; i < mCategoryVO.getData().getCategories().size(); i++) {
                if (mCategoryVO.getData().getCategories().get(i) == headMenu) {
//                    leftAdapter.setSelectedNum(i);
                    break;
                }
            }
        }
    }

    @Override
    public void bindViewsListener() {
        leftAdapter.setListener(this);
    }
    @Override
    public BaseVO getData() {
        RequestParams paramsMap = new RequestParams();
        String mUrl = Constant.CATEGORY_URL;
        return HttpClientUtil.getRequest(mActivity, this, mUrl, paramsMap, CategoryVO.class);
    }

    @Override
    public void hasData(BaseVO vo) {
        mCategoryVO = (CategoryVO) vo;

        leftAdapter.updateData(mCategoryVO.getDatas().getClass_list());
        leftMenu.setAdapter(leftAdapter);



//        rightAdapter.updateData(dishMenuList);
        updateChild(mCategoryVO.getDatas().getClass_list().get(0));
        rightMenu.setAdapter(rightAdapter);

//        leftAdapter.addItemSelectedListener(this);
        initHeadView();

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {
    }


    @Override
    public void onLeftItemSelected(CategoryVO menu) {
        updateChild(menu);
    }

    public void updateChild(CategoryVO vo){
        dishMenuList.clear();
        for (int i = 0; i <vo.getChild().size() ; i++) {
            dishMenuList.add(vo.getChild().get(i));
            for (int j = 0; j < vo.getChild().get(i).getGrandson().size(); j++) {
                dishMenuList.add(vo.getChild().get(i).getGrandson().get(j));
            }
        }

        rightAdapter.updateData(dishMenuList);
    }
}
