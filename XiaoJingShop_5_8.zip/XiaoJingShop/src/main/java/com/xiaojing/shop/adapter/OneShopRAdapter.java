package com.xiaojing.shop.adapter;

import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;

import com.wuzhanglong.library.adapter.RecyclerBaseAdapter;
import com.wuzhanglong.library.view.ScaleTransitionPagerTitleView;
import com.xiaojing.shop.R;
import com.xiaojing.shop.fragment.OneShopFragment;
import com.xiaojing.shop.mode.HomeVO;

import net.lucode.hackware.magicindicator.MagicIndicator;
import net.lucode.hackware.magicindicator.ViewPagerHelper;
import net.lucode.hackware.magicindicator.buildins.UIUtil;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;

import java.util.ArrayList;

import cn.bingoogolapple.androidcommon.adapter.BGAViewHolderHelper;

/**
 * Created by Administrator on 2017/2/13.
 */

public class OneShopRAdapter extends RecyclerBaseAdapter<HomeVO> {
    public OneShopRAdapter(RecyclerView recyclerView) {
        super(recyclerView, R.layout.home_adapter_type1);
    }
    private String[] mTitleDataList={"人气","进度","最新揭晓"};
    private ArrayList<Fragment> mFragmentList;
    private MagicIndicator mMagicIndicator;

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void initData(BGAViewHolderHelper helper, int position, Object model) {
        HomeVO homeVO = (HomeVO) model;

        if(position==0){

        }else if(position==1){
            mMagicIndicator =helper.getView(R.id.magic_indicator);
        }else{
            ViewPager    viewPager=helper.getView(R.id.view_pager);
            initViewPagerData(viewPager);
            initMagicIndicator(mMagicIndicator, viewPager) ;

        }
    }

    private void initMagicIndicator(MagicIndicator magicIndicator, final ViewPager viewPager) {
//        MagicIndicator magicIndicator = (MagicIndicator) findViewById(R.id.magic_indicator);
        magicIndicator.setBackgroundColor(Color.WHITE);
        CommonNavigator commonNavigator = new CommonNavigator(mActivity);
        commonNavigator.setAdjustMode(true);
        commonNavigator.setAdapter(new CommonNavigatorAdapter() {
            @Override
            public int getCount() {
                return mTitleDataList == null ? 0 : mTitleDataList.length;
            }

            @Override
            public IPagerTitleView getTitleView(Context context, final int index) {
                SimplePagerTitleView simplePagerTitleView = new ScaleTransitionPagerTitleView(context);
                simplePagerTitleView.setText(mTitleDataList[index]);
                simplePagerTitleView.setTextSize(18);
                simplePagerTitleView.setNormalColor(Color.parseColor("#616161"));
                simplePagerTitleView.setSelectedColor(Color.parseColor("#f57c00"));
                simplePagerTitleView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        viewPager.setCurrentItem(index);
                    }
                });
                return simplePagerTitleView;
            }

            @Override
            public IPagerIndicator getIndicator(Context context) {
                LinePagerIndicator indicator = new LinePagerIndicator(context);
                indicator.setStartInterpolator(new AccelerateInterpolator());
                indicator.setEndInterpolator(new DecelerateInterpolator(1.6f));
//                indicator.setYOffset(UIUtil.dip2px(context, 39));
                indicator.setLineHeight(UIUtil.dip2px(context, 2));
                indicator.setColors(Color.parseColor("#f57c00"));
//                LinePagerIndicator indicator = new LinePagerIndicator(context);
//                indicator.setColors(Color.parseColor("#40c4ff"));
                return indicator;
            }

            @Override
            public float getTitleWeight(Context context, int index) {
                if (index == 0) {
                    return 1.0f;
                } else if (index == 1) {
                    return 1.0f;
                } else {
                    return 1.0f;
                }
            }
        });

        magicIndicator.setNavigator(commonNavigator);
        ViewPagerHelper.bind(magicIndicator, viewPager);


    }

    public void initViewPagerData(ViewPager viewPager){
        mFragmentList=new ArrayList<>();
        for (int i = 0; i <mTitleDataList.length ; i++) {
            mFragmentList.add(OneShopFragment.newInstance());
        }
        viewPager.setAdapter(new FragmentPagerAdapter(mActivity.getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return mFragmentList.get(position);
            }

            @Override
            public int getCount() {
                return mFragmentList.size();
            }
        });

    }


    @Override
    public int getItemViewType(int position) {
        return getViewByType(position);
    }

    public int getViewByType(int type) {
        int viewType = 0;
        switch (type) {
            case 0:
                viewType = R.layout.one_shop_item_type1;
                break;
            case 1:
                viewType = R.layout.one_shop_item_type2;
                break;
            case 2:
                viewType = R.layout.one_shop_item_type3;
                break;
            default:
                break;
        }
        return viewType;
    }

    @Override
    public int getItemCount() {
        return 3;
    }
}
