package com.xiaojing.shop.fragment;

import android.support.v7.widget.LinearLayoutManager;
import android.view.View;

import com.github.jdsjlzx.recyclerview.LRecyclerView;
import com.github.jdsjlzx.recyclerview.LRecyclerViewAdapter;
import com.google.gson.Gson;
import com.wuzhanglong.library.ItemDecoration.StickyHeaderDecoration;
import com.wuzhanglong.library.fragment.BaseFragment;
import com.wuzhanglong.library.mode.BaseVO;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.HomeLRAdapter;
import com.xiaojing.shop.mode.CategoryVO;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import cn.bingoogolapple.androidcommon.adapter.BGADivider;

/**
 * Created by Administrator on 2017/2/9.
 */

public class TabThreeFragment extends BaseFragment{
    private LRecyclerView mLRecyclerView;
    private HomeLRAdapter mHomeLRAdapter;
    private StickyHeaderDecoration decor;
    private CategoryVO mCategoryVO;
    @Override
    public void setContentView() {
        View.inflate(mActivity, R.layout.tab_three_fragment,mBaseContentLayout);
    }

    @Override
    public void initView(View view) {
        mLRecyclerView=getViewById(R.id.recycler_view);
        mLRecyclerView.setPullRefreshEnabled(false);

        mLRecyclerView.addItemDecoration(BGADivider.newShapeDivider() //设置分割线,用BGADivider 可以去掉分类顶部的分割线
                .setMarginLeftDp(4)
                .setMarginRightDp(1)
                .setDelegate(new BGADivider.SimpleDelegate() {
                    @Override
                    public boolean isNeedSkip(int position, int itemCount) {
                        // 如果是分类的话就跳过，顶部不绘制分隔线
                        if(position/5==0){
                            return true;
                        }else{
                            return false;
                        }
                    }
                }));
        mLRecyclerView.setHasFixedSize(true);

//        GridLayoutManager mLayoutManager = new GridLayoutManager(mActivity, 3);


        mHomeLRAdapter= new HomeLRAdapter(mActivity);

        decor= new StickyHeaderDecoration(mHomeLRAdapter);

        LRecyclerViewAdapter adapter= new LRecyclerViewAdapter(mHomeLRAdapter);
        mLRecyclerView.setAdapter(adapter);

        mLRecyclerView.addItemDecoration(decor, 1);

//        List<CategoryVO> list = new ArrayList<>();
//        for (int i = 0; i < 30; i++) {
//            CategoryVO vo = new CategoryVO();
//            list.add(vo);
//        }

        InputStream inputStream = null;
        try {
            inputStream = mActivity.getAssets().open("liwushuo.txt");
            int size = inputStream.available();
            int len = -1;
            byte[] bytes = new byte[size];
            inputStream.read(bytes);
            inputStream.close();
            String string = new String(bytes);
            final Gson gson = new Gson();
            mCategoryVO = (CategoryVO) gson.fromJson(string, CategoryVO.class);
        } catch (Exception e) {
            e.printStackTrace();
        }


        List<CategoryVO> list = new ArrayList<>();
        for (int i = 0; i <mCategoryVO.getData().getCategories().size() ; i++) {
//            list.add(mCategoryVO.getData().getCategories().get(i));
            for (int j = 0; j < mCategoryVO.getData().getCategories().get(i).getSubcategories().size(); j++) {
                list.add(mCategoryVO.getData().getCategories().get(i).getSubcategories().get(j));
    }
}
        mHomeLRAdapter.updateData(list);
//        mLRecyclerView.setLayoutManager(new GridLayoutManager(mActivity, 3));
        mLRecyclerView.setLayoutManager(new LinearLayoutManager(mActivity));

//        mLRecyclerView.setLayoutManager(new GridLayoutManager(mActivity, 3));

//        mLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
//            @Override
//            public int getSpanSize(int position) {
//                switch ((int) mHomeLRAdapter.getHeaderId(position)) {
//                    case 0:
//                        System.out.println("=================>");
//                        return 3;
//                    default:
//                        return 1;
//                }
//            }
//        });

    }

    @Override
    public void bindViewsListener() {

    }

    @Override
    public BaseVO getData() {
//        showView();
        return null;
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }




}
