package com.xiaojing.shop.activity;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;

import com.github.jdsjlzx.interfaces.OnLoadMoreListener;
import com.github.jdsjlzx.recyclerview.LuRecyclerView;
import com.github.jdsjlzx.recyclerview.LuRecyclerViewAdapter;
import com.github.jdsjlzx.recyclerview.ProgressStyle;
import com.loopj.android.http.RequestParams;
import com.wuzhanglong.library.ItemDecoration.DividerDecoration;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.http.HttpClientUtil;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.DividerUtil;
import com.wuzhanglong.library.view.AutoSwipeRefreshLayout;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.HistoryShopRadapter;
import com.xiaojing.shop.application.AppApplication;
import com.xiaojing.shop.constant.Constant;
import com.xiaojing.shop.mode.HistoryShopVO;

public class HistoryShopActivity extends BaseActivity implements OnLoadMoreListener, SwipeRefreshLayout.OnRefreshListener{
    private AutoSwipeRefreshLayout mAutoSwipeRefreshLayout;
    private LuRecyclerView mRecyclerView;
    private HistoryShopRadapter mAdapter;

    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.history_shop_activity);
    }

    @Override
    public void initView() {
        mBaseTitleTv.setText("我的足迹");
        mAutoSwipeRefreshLayout=getViewById(R.id.swipe_refresh_layout);
        mActivity.setSwipeRefreshLayoutColors(mAutoSwipeRefreshLayout);

        mRecyclerView = getViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mActivity));
        mAdapter = new HistoryShopRadapter(mRecyclerView);
        LuRecyclerViewAdapter adapter = new LuRecyclerViewAdapter(mAdapter);
        mRecyclerView.setAdapter(adapter);
        DividerDecoration divider = DividerUtil.linnerDivider(this,R.dimen.dp_1,R.color.C3);
        mRecyclerView.addItemDecoration(divider);
        mRecyclerView.setLoadingMoreProgressStyle(ProgressStyle.BallSpinFadeLoader);
        mRecyclerView.setLoadMoreEnabled(true);
        initData();
    }

    @Override
    public void bindViewsListener() {
        mAutoSwipeRefreshLayout.setOnRefreshListener(this);
    }

    @Override
    public BaseVO getData() {
//        showView();
        return null;
    }
    public void initData(){
        RequestParams paramsMap = new RequestParams();
        String mUrl = Constant.HISTORY_SHOP_URL;
        paramsMap.put("key", AppApplication.getInstance().getUserInfoVO().getKey());
//        paramsMap.put("curpage","1");
         HttpClientUtil.get(mActivity, this, mUrl, paramsMap, HistoryShopVO.class);
    }

    @Override
    public void hasData(BaseVO vo) {
        HistoryShopVO historyShopVO= (HistoryShopVO) vo;
        mAdapter.updateData(historyShopVO.getDatas().getGoodsbrowse_list());
    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    @Override
    public void onRefresh() {
        mAutoSwipeRefreshLayout.setRefreshing(false);
    }

    @Override
    public void onLoadMore() {

    }
}
