package com.xiaojing.shop.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.xiaojing.shop.R;
import com.xiaojing.shop.mode.CategoryVO;

import java.util.List;

import cc.solart.turbo.BaseTurboAdapter;
import cc.solart.turbo.BaseViewHolder;

/**
 * Created by Administrator on 2017/2/13.
 */

public class CategoryRAdapter extends  BaseTurboAdapter<CategoryVO, BaseViewHolder> {
    public CategoryRAdapter(Context context) {
        super(context);
    }

    public CategoryRAdapter(Context context, List<CategoryVO> data) {
        super(context, data);
    }

    @Override
    protected int getDefItemViewType(int position) {
//        ContactCityBean city = getItem(position);
//        return city.type;
        CategoryVO vo= (CategoryVO) mData.get(position);
        if(vo.getGrandson() !=null){
            return 1;
        }else{
            return 0;
        }
    }

    @Override
    protected BaseViewHolder onCreateDefViewHolder(ViewGroup parent, int viewType) {
        if (viewType == 1)
            return new CityHolder(inflateItemView(R.layout.right_dish_item1, parent));
        else
            return new PinnedHolder(inflateItemView(R.layout.right_menu_item, parent));
    }


    @Override
    protected void convert(BaseViewHolder holder, CategoryVO item) {
        if (holder instanceof CityHolder) {
//            ((CityHolder) holder).city_name.setText(item.name);
            ((CityHolder) holder).child_itme.setText(item.getGc_name());
            Picasso.with(mContext).load(item.getGc_image()).into(((CityHolder) holder).img);
        }else {
//            String letter = item.pys.substring(0, 1);
//            ((PinnedHolder) holder).city_tip.setText(letter);
            ((PinnedHolder) holder).right_menu_tv.setText(item.getGc_name());
        }
    }

//    public int getLetterPosition(String letter){
//        for (int i = 0 ; i < getData().size(); i++){
//            if(getData().get(i).type ==1 && getData().get(i).pys.equals(letter)){
//                return i;
//            }
//        }
//        return -1;
//    }

    class CityHolder extends BaseViewHolder {

        TextView child_itme;
        ImageView img;

        public CityHolder(View view) {
            super(view);
            child_itme = findViewById(R.id.child_itme);
            img=findViewById(R.id.img);
        }
    }


    class PinnedHolder extends BaseViewHolder {

        TextView right_menu_tv;

        public PinnedHolder(View view) {
            super(view);
            right_menu_tv = findViewById(R.id.right_menu_tv);
        }
    }




}
