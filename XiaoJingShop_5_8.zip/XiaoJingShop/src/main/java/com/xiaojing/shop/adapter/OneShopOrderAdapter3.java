package com.xiaojing.shop.adapter;

import android.support.v7.widget.RecyclerView;

import com.wuzhanglong.library.adapter.RecyclerBaseAdapter;
import com.xiaojing.shop.R;
import com.xiaojing.shop.mode.HomeVO;

import cn.bingoogolapple.androidcommon.adapter.BGAViewHolderHelper;

/**
 * Created by Administrator on 2017/2/13.
 */

public class OneShopOrderAdapter3 extends RecyclerBaseAdapter<HomeVO> {
    public OneShopOrderAdapter3(RecyclerView recyclerView) {
        super(recyclerView, R.layout.one_shop_order_adapter3);
    }

    @Override
    public void initData(BGAViewHolderHelper helper, int position, Object model) {
//        helper.setText(R.id.name,"我草草草");

    }

    @Override
    public int getItemCount() {
        return 15;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.one_shop_order_adapter3;
    }
}
