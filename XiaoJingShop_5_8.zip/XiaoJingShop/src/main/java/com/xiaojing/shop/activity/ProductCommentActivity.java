package com.xiaojing.shop.activity;

import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.mode.BaseVO;
import com.xiaojing.shop.R;

public class ProductCommentActivity extends BaseActivity {

    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.product_comment_activity);
    }

    @Override
    public void initView() {

    }

    @Override
    public void bindViewsListener() {

    }

    @Override
    public BaseVO getData() {
//        showView();
        return null;
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }


}
