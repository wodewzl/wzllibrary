package com.xiaojing.shop.mode;

import com.wuzhanglong.library.mode.BaseVO;

import java.util.List;

/**
 * Created by ${Wuzhanglong} on 2017/5/5.
 */

public class MoneyVO extends BaseVO{
        private MoneyVO datas;
        private List<MoneyVO> list;
        private String lg_id;
        private String lg_member_id;
        private String lg_member_name;
        private String lg_type;
        private String lg_av_amount;
        private String lg_add_time;
        private String lg_desc;

    public MoneyVO getDatas() {
        return datas;
    }

    public void setDatas(MoneyVO datas) {
        this.datas = datas;
    }

    public List<MoneyVO> getList() {
        return list;
    }

    public void setList(List<MoneyVO> list) {
        this.list = list;
    }

    public String getLg_id() {
        return lg_id;
    }

    public void setLg_id(String lg_id) {
        this.lg_id = lg_id;
    }

    public String getLg_member_id() {
        return lg_member_id;
    }

    public void setLg_member_id(String lg_member_id) {
        this.lg_member_id = lg_member_id;
    }

    public String getLg_member_name() {
        return lg_member_name;
    }

    public void setLg_member_name(String lg_member_name) {
        this.lg_member_name = lg_member_name;
    }

    public String getLg_type() {
        return lg_type;
    }

    public void setLg_type(String lg_type) {
        this.lg_type = lg_type;
    }

    public String getLg_av_amount() {
        return lg_av_amount;
    }

    public void setLg_av_amount(String lg_av_amount) {
        this.lg_av_amount = lg_av_amount;
    }

    public String getLg_add_time() {
        return lg_add_time;
    }

    public void setLg_add_time(String lg_add_time) {
        this.lg_add_time = lg_add_time;
    }

    public String getLg_desc() {
        return lg_desc;
    }

    public void setLg_desc(String lg_desc) {
        this.lg_desc = lg_desc;
    }
}
