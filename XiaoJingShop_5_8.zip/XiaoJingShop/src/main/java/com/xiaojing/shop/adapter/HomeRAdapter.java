package com.xiaojing.shop.adapter;

import android.content.Context;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;
import com.wuzhanglong.library.adapter.RecyclerBaseAdapter;
import com.wuzhanglong.library.utils.BaseCommonUtils;
import com.xiaojing.shop.R;
import com.xiaojing.shop.activity.NearbyShopActivity;
import com.xiaojing.shop.activity.ShopListActivity;
import com.xiaojing.shop.mode.HomeVO;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.loader.ImageLoader;

import cn.bingoogolapple.androidcommon.adapter.BGAOnItemChildClickListener;
import cn.bingoogolapple.androidcommon.adapter.BGAViewHolderHelper;

/**
 * Created by Administrator on 2017/2/13.
 */

public class HomeRAdapter extends RecyclerBaseAdapter<HomeVO> {
    public HomeRAdapter(RecyclerView recyclerView) {
        super(recyclerView, R.layout.home_adapter_type1);
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void initData(BGAViewHolderHelper helper, int position, Object model) {
        HomeVO homeVO = (HomeVO) model;
        switch (getItemViewType(position)) {
            case R.layout.home_adapter_type0:
                Banner banner = helper.getView(R.id.banner);
                banner.setBannerStyle(BannerConfig.CIRCLE_INDICATOR);
                banner.setImageLoader(new ImageLoader() {
                    @Override
                    public void displayImage(Context context, Object o, ImageView imageView) {
                        HomeVO homeVO = (HomeVO) o;
                        Picasso.with(context).load(homeVO.getImage()).into(imageView);
                    }
                });
                banner.setIndicatorGravity(BannerConfig.CENTER);
                banner.setImages(homeVO.getItem_data().getItem());
                banner.start();

                helper.setItemChildClickListener(R.id.type_01_tv);
                helper.setItemChildClickListener(R.id.type_02_tv);
                helper.setItemChildClickListener(R.id.type_03_tv);
                helper.setItemChildClickListener(R.id.type_04_tv);
                helper.setItemChildClickListener(R.id.type_05_tv);
                helper.setItemChildClickListener(R.id.type_06_tv);
                helper.setItemChildClickListener(R.id.type_07_tv);
                helper.setItemChildClickListener(R.id.type_08_tv);
                helper.setOnItemChildClickListener(new BGAOnItemChildClickListener() {
                    @Override
                    public void onItemChildClick(ViewGroup viewGroup, View v, int i) {
                        switch (v.getId()) {
                            case R.id.type_01_tv:
                                mActivity.openActivity(NearbyShopActivity.class);
                                break;
                            case R.id.type_05_tv:
                                mActivity.openActivity(ShopListActivity.class);
                                break;
                            default:
                                break;
                        }
                    }
                });

                break;

            case R.layout.home_adapter_type2:
                helper.setText(R.id.type2, homeVO.getItem_data().getTitle());
                Picasso.with(mContext).load(homeVO.getItem_data().getRectangle1_image()).into(helper.getImageView(R.id.type1_img1));
                Picasso.with(mContext).load(homeVO.getItem_data().getRectangle2_image()).into(helper.getImageView(R.id.type1_img2));
                Picasso.with(mContext).load(homeVO.getItem_data().getRectangle3_image()).into(helper.getImageView(R.id.type1_img3));
                Picasso.with(mContext).load(homeVO.getItem_data().getRectangle4_image()).into(helper.getImageView(R.id.type1_img4));
                Picasso.with(mContext).load(homeVO.getItem_data().getRectangle5_image()).into(helper.getImageView(R.id.type1_img5));
                break;
            case R.layout.home_adapter_type3:
                Picasso.with(mContext).load(homeVO.getItem_data().getImage()).into(helper.getImageView(R.id.type3_img));
                break;
            case R.layout.home_adapter_type4:
                helper.setText(R.id.type4, homeVO.getItem_data().getTitle());
                Picasso.with(mContext).load(homeVO.getItem_data().getRectangle1_image()).into(helper.getImageView(R.id.type4_img1));
                Picasso.with(mContext).load(homeVO.getItem_data().getRectangle2_image()).into(helper.getImageView(R.id.type4_img2));
                Picasso.with(mContext).load(homeVO.getItem_data().getRectangle3_image()).into(helper.getImageView(R.id.type4_img3));
                Picasso.with(mContext).load(homeVO.getItem_data().getRectangle4_image()).into(helper.getImageView(R.id.type4_img4));
                Picasso.with(mContext).load(homeVO.getItem_data().getRectangle5_image()).into(helper.getImageView(R.id.type4_img5));
                break;
            case R.layout.home_adapter_type5:
                LinearLayout rootLayout = helper.getView(R.id.type5_root_layout);
                if (homeVO.getItem_data().getItem().size() % 2 == 0) {
                    if (rootLayout.getChildCount() == homeVO.getItem_data().getItem().size() / 2) {
                        return;
                    }
                } else {
                    if (rootLayout.getChildCount() == (homeVO.getItem_data().getItem().size() / 2 + 1)) {
                        return;
                    }
                }
                rootLayout.removeAllViews();
                for (int i = 0; i < homeVO.getItem_data().getItem().size(); i++) {
                    if (homeVO.getItem_data().getItem().size() % 2 == 0) {
                        if (i % 2 == 0) {
                            View view = View.inflate(mContext, R.layout.home_adapter_type5_2, null);
                            rootLayout.addView(view);
                            TextView type5_title1 = (TextView) view.findViewById(R.id.type5_title1);
                            type5_title1.setText(homeVO.getItem_data().getItem().get(i).getGoods_name());
                            TextView type5_price1 = (TextView) view.findViewById(R.id.type5_price1);
                            type5_price1.setText(homeVO.getItem_data().getItem().get(i).getGoods_price());
                            ImageView type5_img1 = (ImageView) view.findViewById(R.id.type5_img1);
                            Picasso.with(mContext).load(homeVO.getItem_data().getItem().get(i).getGoods_image()).into(type5_img1);
                            TextView type5_same1 = (TextView) view.findViewById(R.id.type5_same1);
                            type5_same1.setBackground(BaseCommonUtils.setBackgroundShap(mContext, 5, R.color.C3_1, R.color.C1));

                            TextView type5_title2 = (TextView) view.findViewById(R.id.type5_title2);
                            type5_title2.setText(homeVO.getItem_data().getItem().get(i + 1).getGoods_name());
                            TextView type5_price2 = (TextView) view.findViewById(R.id.type5_price2);
                            type5_price2.setText(homeVO.getItem_data().getItem().get(i + 1).getGoods_price());
                            ImageView type5_img2 = (ImageView) view.findViewById(R.id.type5_img2);
                            Picasso.with(mContext).load(homeVO.getItem_data().getItem().get(i + 1).getGoods_image()).into(type5_img2);
                            TextView type5_same2 = (TextView) view.findViewById(R.id.type5_same2);
                            type5_same2.setBackground(BaseCommonUtils.setBackgroundShap(mContext, 5, R.color.C3_1, R.color.C1));
                        }
                    } else {
                        if (i % 2 == 0 && i < homeVO.getItem_data().getItem().size() - 1) {
                            View view = View.inflate(mContext, R.layout.home_adapter_type5_2, null);
                            rootLayout.addView(view);
                            TextView type5_title1 = (TextView) view.findViewById(R.id.type5_title1);
                            type5_title1.setText(homeVO.getItem_data().getItem().get(i).getGoods_name());
                            TextView type5_price1 = (TextView) view.findViewById(R.id.type5_price1);
                            type5_price1.setText(homeVO.getItem_data().getItem().get(i).getGoods_price());
                            ImageView type5_img1 = (ImageView) view.findViewById(R.id.type5_img1);
                            Picasso.with(mContext).load(homeVO.getItem_data().getItem().get(i).getGoods_image()).into(type5_img1);
                            TextView type5_same1 = (TextView) view.findViewById(R.id.type5_same1);
                            type5_same1.setBackground(BaseCommonUtils.setBackgroundShap(mContext, 5, R.color.C3_1, R.color.C1));

                            TextView type5_title2 = (TextView) view.findViewById(R.id.type5_title2);
                            type5_title2.setText(homeVO.getItem_data().getItem().get(i + 1).getGoods_name());
                            TextView type5_price2 = (TextView) view.findViewById(R.id.type5_price2);
                            type5_price2.setText(homeVO.getItem_data().getItem().get(i + 1).getGoods_price());
                            ImageView type5_img2 = (ImageView) view.findViewById(R.id.type5_img2);
                            Picasso.with(mContext).load(homeVO.getItem_data().getItem().get(i + 1).getGoods_image()).into(type5_img2);
                            TextView type5_same2 = (TextView) view.findViewById(R.id.type5_same2);
                            type5_same2.setBackground(BaseCommonUtils.setBackgroundShap(mContext, 5, R.color.C3_1, R.color.C1));
                        } else {
                            if (i == homeVO.getItem_data().getItem().size() - 1) {
                                View view = View.inflate(mContext, R.layout.home_adapter_type5_1, null);
                                rootLayout.addView(view);
                                TextView type5_title1 = (TextView) view.findViewById(R.id.type5_title1);
                                type5_title1.setText(homeVO.getItem_data().getItem().get(i).getGoods_name());
                                TextView type5_price1 = (TextView) view.findViewById(R.id.type5_price1);
                                type5_price1.setText(homeVO.getItem_data().getItem().get(i).getGoods_price());
                                ImageView type5_img1 = (ImageView) view.findViewById(R.id.type5_img1);
                                Picasso.with(mContext).load(homeVO.getItem_data().getItem().get(i).getGoods_image()).into(type5_img1);
                                TextView type5_same1 = (TextView) view.findViewById(R.id.type5_same1);
                                type5_same1.setBackground(BaseCommonUtils.setBackgroundShap(mContext, 5, R.color.C3_1, R.color.C1));
                            }
                        }
                    }
                }
                break;
            default:
                break;
        }

    }


    @Override
    public int getItemViewType(int position) {
        HomeVO homeVO = (HomeVO) mData.get(position);
        int type = BaseCommonUtils.parseInt(homeVO.getType());
        return getViewByType(type);
    }

    public int getViewByType(int type) {
        int viewType = 0;
        switch (type) {
            case 1:
                viewType = R.layout.home_adapter_type0;
                break;
            case 2:
                viewType = R.layout.home_adapter_type3;
                break;
            case 3:
                viewType = R.layout.home_adapter_type2;
                break;
            case 4:
                viewType = R.layout.home_adapter_type4;
                break;
            case 5:
                viewType = R.layout.home_adapter_type5;
                break;
            default:
                break;
        }
        return viewType;
    }
}
