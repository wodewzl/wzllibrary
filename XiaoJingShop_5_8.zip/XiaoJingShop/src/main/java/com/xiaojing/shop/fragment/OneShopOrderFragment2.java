package com.xiaojing.shop.fragment;

import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.view.View;

import com.github.jdsjlzx.ItemDecoration.SpacesItemDecoration;
import com.github.jdsjlzx.recyclerview.LRecyclerView;
import com.github.jdsjlzx.recyclerview.LRecyclerViewAdapter;
import com.wuzhanglong.library.fragment.BaseFragment;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.view.AutoSwipeRefreshLayout;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.OneShopOrderAdapter2;

public class OneShopOrderFragment2 extends BaseFragment {
    private AutoSwipeRefreshLayout mAutoSwipeRefreshLayout;
    private LRecyclerView mRecyclerView;
    private OneShopOrderAdapter2 mAdapter;
    public static BaseFragment newInstance() {
        BaseFragment fragment = new OneShopOrderFragment2();
//        Bundle args = new Bundle();
//        args.putString(ARG_PARAM1, param1);
//        args.putString(ARG_PARAM2, param2);
//        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public BaseVO getData() {
//        showView();
        return null;
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    @Override
    public void setContentView() {
        contentInflateView(R.layout.one_shop_order_fragment);
    }

    @Override
    public void initView(View view) {

//        mAutoSwipeRefreshLayout=getViewById(R.id.swipe_refresh_layout);
//        mActivity.setSwipeRefreshLayoutColors(mAutoSwipeRefreshLayout);
        mRecyclerView=getViewById(R.id.recycler_view);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(mActivity));
        mAdapter= new OneShopOrderAdapter2(mRecyclerView);
        LRecyclerViewAdapter adapter= new LRecyclerViewAdapter(mAdapter);
        mRecyclerView.setAdapter(adapter);

        int spacing = getResources().getDimensionPixelSize(R.dimen.dp_4);
        mRecyclerView.addItemDecoration(SpacesItemDecoration.newInstance(spacing, spacing, 2, ContextCompat.getColor(mActivity,R.color.C2)));

//        GridItemDecoration divider = new GridItemDecoration.Builder(mActivity)
//                .setHorizontal(R.dimen.dp_4)
//                .setVertical(R.dimen.dp_4)
//                .setColorResource(R.color.C7)
//                .build();
//        mRecyclerView.addItemDecoration(divider);
    }

    @Override
    public void bindViewsListener() {

    }
}
