package com.xiaojing.shop.activity;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.content.ContextCompat;
import android.view.View;

import com.loopj.android.http.RequestParams;
import com.rey.material.widget.Button;
import com.rey.material.widget.TextView;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.fragment.BaseFragment;
import com.wuzhanglong.library.http.HttpClientUtil;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.BaseCommonUtils;
import com.wuzhanglong.library.utils.ViewColorUtil;
import com.xiaojing.shop.R;
import com.xiaojing.shop.application.AppApplication;
import com.xiaojing.shop.constant.Constant;
import com.xiaojing.shop.fragment.TabFourFragment;
import com.xiaojing.shop.fragment.TabOneFragment;
import com.xiaojing.shop.fragment.TabThreeFragment;
import com.xiaojing.shop.fragment.TabTwoFragment;
import com.xiaojing.shop.mode.UserInfoVO;

import net.anumbrella.customedittext.FloatLabelView;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class LoginActivity extends BaseActivity implements View.OnClickListener {
    private FloatLabelView mAccountTv, mPasswordTv;
    private Button mLoginBt;
    private TextView mRegistTv, mResetTv, mPhoneTv;


    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.login_activity);
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void initView() {
        mBaseTitleTv.setVisibility(View.GONE);
        mBaseBackTv.setVisibility(View.GONE);
        mBaseHeadLayout.setBackgroundResource(R.color.C1);
        int[] colors = new int[]{ContextCompat.getColor(this, R.color.C1), ContextCompat.getColor(this, R.color.C1), Color.parseColor("#5f000000")};
        ViewColorUtil.viewGradient(colors, mBaseHeadLayout, 2);
        mAccountTv = getViewById(R.id.account);
        mPasswordTv = getViewById(R.id.password);
        mLoginBt = getViewById(R.id.login_bt);
        mLoginBt.setBackgroundDrawable(BaseCommonUtils.setBackgroundShap(this, BaseCommonUtils.dip2px(this, 2), R.color.C7, R.color.C7));
        mRegistTv = getViewById(R.id.regist_tv);
        mResetTv = getViewById(R.id.reset_tv);
        mPhoneTv = getViewById(R.id.phone_tv);
    }

    @Override
    public void bindViewsListener() {
        mLoginBt.setOnClickListener(this);
        mRegistTv.setOnClickListener(this);
        mResetTv.setOnClickListener(this);
        mPhoneTv.setOnClickListener(this);
    }

    @Override
    public BaseVO getData() {
        showView();
        return null;
    }

    @Override
    public void hasData(BaseVO vo) {
        UserInfoVO userInfoVO = (UserInfoVO) vo;
        AppApplication.getInstance().saveUserInfoVO(userInfoVO);
        Intent intent = new Intent();
        List<BaseFragment> list = new ArrayList<>();
        TabOneFragment one = new TabOneFragment();
        TabTwoFragment two = new TabTwoFragment();
        TabThreeFragment three = new TabThreeFragment();
        TabFourFragment four = new TabFourFragment();
        list.add(one);
        list.add(two);
        list.add(three);
        list.add(four);
        intent.putExtra("fragment_list", (Serializable) list);
        intent.setClass(this,HomeActivity.class);
        startActivity(intent);
    }

    @Override
    public void noData(BaseVO vo) {
    }

    @Override
    public void noNet() {
    }

    @Override
    public boolean supportSlideBack() {
        return false;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.login_bt:
                login();
                break;
            case R.id.regist_tv:
                openActivity(RegistActivity.class);
                break;
            case R.id.reset_tv:
                openActivity(ResetPasswordActivity.class);
                break;
            case R.id.phone_tv:
//                BaseCommonUtils.call(this,mPhoneTv.getText().toString());
                break;

            default:
                break;
        }
    }

    public void login() {
        RequestParams paramsMap = new RequestParams();
        paramsMap.put("username", mAccountTv.getEditText().getText().toString());
        paramsMap.put("password", mPasswordTv.getEditText().getText().toString());
        String mUrl = Constant.LOGIN_URL;
        HttpClientUtil.post(mActivity, this, mUrl, paramsMap, UserInfoVO.class);
    }
}
