package com.xiaojing.shop.constant;

import cz.msebera.android.httpclient.protocol.HTTP;

public class Constant {

	public static final String FIRSTID = "firstid";
	public static final String LASTID = "lastid";
	public static final String ENCODING = HTTP.UTF_8;
//	public static final String SDCARD_CACHE = "com.synews/files/"; // 文件sdk缓存


	//get 最后加 &
	public static final String LOGIN_URL = "act=login&op=index";// 登录接口
	public static final String GET_CODE = "act=connect&op=get_sms_captcha&";// 获取验证码
	public static final String REGIST_URL = "act=connect&op=sms_register";// 注册
	public static final String CATEGORY_URL = "act=goods_class&op=index&";// 商品分类
	public static final String GET_ADDRESS_URL = "act=member_address&op=address_list&";// 获取地址
	public static final String GET_CITY_URL = "act=index&op=get_area_list&";// 获取城市列表
	public static final String ADD_ADDRESS_URL = "act=member_address&op=address_add";// 添加地址
	public static final String DELETE_ADDRESS_URL = "act=member_address&op=address_del&";// 删除地址
	public static final String EDIT_ADDRESS_URL = "act=member_address&op=address_edit";// 编辑地址
	public static final String DEFALULT_ADDRESS_URL = "act=member_address&op=set_default&";//收货地址设置默认
	public static final String KEYWORD_URL = "act=index&op=search_key_list&";//关键字
	public static final String SHOP_LIST_URL = "act=goods&op=goods_list&";//商品列表
	public static final String HOME_URL = "act=index&op=index&";//首页界面
	public static final String HISTORY_SHOP_URL = "act=member_goodsbrowse&op=browse_list&";//我的足迹
	public static final String MY_URL = "act=member_index&op=index&";//个人中心
	public static final String MY_OVER_URL = "act=member_fund&op=predepositlog&";//个人中心





}
