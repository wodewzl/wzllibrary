package com.xiaojing.shop.activity;


import android.view.View;

import com.rey.material.widget.LinearLayout;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.mode.BaseVO;
import com.xiaojing.shop.R;

public class SettingActivity extends BaseActivity implements View.OnClickListener{
    private LinearLayout mLayout03;

    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.setting_activity);
    }

    @Override
    public void initView() {
        mLayout03=getViewById(R.id.layout_03);
    }

    @Override
    public void bindViewsListener() {
        mLayout03.setOnClickListener(this);
    }

    @Override
    public BaseVO getData() {
        return null;
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }


    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.layout_03:
                openActivity(AddressActivity.class);
                break;
            default:
                break;
        }
    }
}
