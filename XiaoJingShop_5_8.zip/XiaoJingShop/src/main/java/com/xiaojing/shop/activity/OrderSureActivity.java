package com.xiaojing.shop.activity;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.view.View;

import com.suke.widget.SwitchButton;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.BaseCommonUtils;
import com.xiaojing.shop.R;

public class OrderSureActivity extends BaseActivity implements SwitchButton.OnCheckedChangeListener{
    private SwitchButton mSwitchButton1;

    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.order_sure_activity);
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void initView() {
        mBaseTitleTv.setText("确认订单");
        View xuxian1=getViewById(R.id.xuxian_1);
        View xuxian2=getViewById(R.id.xuxian_2);
        xuxian1.setBackground(BaseCommonUtils.setBackgroundShap(this,0,R.color.XJColor7,R.color.XJColor7,1));
        xuxian2.setBackground(BaseCommonUtils.setBackgroundShap(this,0, R.color.XJColor7,R.color.XJColor7,1));
        mSwitchButton1=getViewById(R.id.switch_button1);
//        mSwitchButton.setChecked(true);
//        mSwitchButton1.isChecked();
//        mSwitchButton1.toggle();     //switch state
//        mSwitchButton.toggle(false);//switch without animation
//        mSwitchButton.setShadowEffect(true);//disable shadow effect
        mSwitchButton1.setEnabled(false);//disable button
    }

    @Override
    public void bindViewsListener() {

    }

    @Override
    public BaseVO getData() {
        return null;
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    @Override
    public void onCheckedChanged(SwitchButton switchButton, boolean b) {

    }
}
