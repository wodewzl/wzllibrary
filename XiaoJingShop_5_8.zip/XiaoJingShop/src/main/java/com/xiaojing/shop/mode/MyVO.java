package com.xiaojing.shop.mode;

import com.wuzhanglong.library.mode.BaseVO;

/**
 * Created by ${Wuzhanglong} on 2017/5/5.
 */

public class MyVO extends BaseVO {
    private MyVO datas;
    private MyVO member_info;
    private String user_name;
    private String avator;
    private String favorites_goods;
    private String foot_prints;
    private String order_nopay_count;
    private String order_notakes_count;
    private String order_noeval_count;
    private String return_count;
    private String bean;
    private String gold;
    private String balance;
    private String is_merchant;

    public MyVO getDatas() {
        return datas;
    }

    public void setDatas(MyVO data) {
        this.datas = data;
    }

    public MyVO getMember_info() {
        return member_info;
    }

    public void setMember_info(MyVO member_info) {
        this.member_info = member_info;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getAvator() {
        return avator;
    }

    public void setAvator(String avator) {
        this.avator = avator;
    }

    public String getFavorites_goods() {
        return favorites_goods;
    }

    public void setFavorites_goods(String favorites_goods) {
        this.favorites_goods = favorites_goods;
    }

    public String getFoot_prints() {
        return foot_prints;
    }

    public void setFoot_prints(String foot_prints) {
        this.foot_prints = foot_prints;
    }

    public String getOrder_nopay_count() {
        return order_nopay_count;
    }

    public void setOrder_nopay_count(String order_nopay_count) {
        this.order_nopay_count = order_nopay_count;
    }

    public String getOrder_notakes_count() {
        return order_notakes_count;
    }

    public void setOrder_notakes_count(String order_notakes_count) {
        this.order_notakes_count = order_notakes_count;
    }

    public String getOrder_noeval_count() {
        return order_noeval_count;
    }

    public void setOrder_noeval_count(String order_noeval_count) {
        this.order_noeval_count = order_noeval_count;
    }

    public String getReturn_count() {
        return return_count;
    }

    public void setReturn_count(String return_count) {
        this.return_count = return_count;
    }

    public String getBean() {
        return bean;
    }

    public void setBean(String bean) {
        this.bean = bean;
    }

    public String getGold() {
        return gold;
    }

    public void setGold(String gold) {
        this.gold = gold;
    }

    public String getBalance() {
        return balance;
    }

    public void setBalance(String balance) {
        this.balance = balance;
    }

    public String getIs_merchant() {
        return is_merchant;
    }

    public void setIs_merchant(String is_merchant) {
        this.is_merchant = is_merchant;
    }
}
