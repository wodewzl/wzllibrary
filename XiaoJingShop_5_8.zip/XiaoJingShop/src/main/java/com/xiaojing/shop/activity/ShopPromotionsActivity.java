package com.xiaojing.shop.activity;

import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.widget.LinearLayoutManager;

import com.github.jdsjlzx.interfaces.OnLoadMoreListener;
import com.github.jdsjlzx.recyclerview.LuRecyclerView;
import com.github.jdsjlzx.recyclerview.LuRecyclerViewAdapter;
import com.github.jdsjlzx.recyclerview.ProgressStyle;
import com.wuzhanglong.library.ItemDecoration.DividerDecoration;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.DividerUtil;
import com.wuzhanglong.library.view.AutoSwipeRefreshLayout;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.ShopPromotionsAdapter;

public class ShopPromotionsActivity extends BaseActivity implements OnLoadMoreListener, SwipeRefreshLayout.OnRefreshListener{
    private AutoSwipeRefreshLayout mAutoSwipeRefreshLayout;
    private LuRecyclerView mRecyclerView;
    private ShopPromotionsAdapter mAdapter;

    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.shop_promotions_activity);
    }

    @Override
    public void initView() {
        mBaseTitleTv.setText("晒单分享");
        mAutoSwipeRefreshLayout=getViewById(R.id.swipe_refresh_layout);
        mActivity.setSwipeRefreshLayoutColors(mAutoSwipeRefreshLayout);

        mRecyclerView = getViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mActivity));
        mAdapter = new ShopPromotionsAdapter(mRecyclerView);
        LuRecyclerViewAdapter adapter = new LuRecyclerViewAdapter(mAdapter);
        mRecyclerView.setAdapter(adapter);
        DividerDecoration divider = DividerUtil.linnerDivider(this,R.dimen.dp_1,R.color.C3);
        mRecyclerView.addItemDecoration(divider);
        mRecyclerView.setLoadingMoreProgressStyle(ProgressStyle.BallSpinFadeLoader);
        mRecyclerView.setLoadMoreEnabled(true);

    }

    @Override
    public void bindViewsListener() {
        mAutoSwipeRefreshLayout.setOnRefreshListener(this);
    }

    @Override
    public BaseVO getData() {
//        RequestParams paramsMap = new RequestParams();
//        String mUrl = Constant.HISTORY_SHOP_URL;
//        paramsMap.put("key", AppApplication.getInstance().getUserInfoVO().getKey());
//        HttpClientUtil.get(mActivity, this, mUrl, paramsMap, HistoryShopVO.class);
        return null;
    }

    @Override
    public void hasData(BaseVO vo) {
    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    @Override
    public void onRefresh() {
        mAutoSwipeRefreshLayout.setRefreshing(false);
    }

    @Override
    public void onLoadMore() {

    }
}
