package com.xiaojing.shop.activity;

import android.support.v7.widget.LinearLayoutManager;
import android.view.View;

import com.github.jdsjlzx.recyclerview.LuRecyclerView;
import com.github.jdsjlzx.recyclerview.LuRecyclerViewAdapter;
import com.loopj.android.http.RequestParams;
import com.rey.material.widget.TextView;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.http.HttpClientUtil;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.DividerUtil;
import com.wuzhanglong.library.view.AutoSwipeRefreshLayout;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.ShopListRadapter;
import com.xiaojing.shop.application.AppApplication;
import com.xiaojing.shop.constant.Constant;
import com.xiaojing.shop.mode.ShopVO;

public class ShopListActivity extends BaseActivity implements View.OnClickListener {
    private LuRecyclerView mLuRecyclerView;
    private AutoSwipeRefreshLayout mSwipeRefresh;
    private ShopListRadapter mAdapter;
    private TextView mPriceTv;
    private int mPriceType = 0;//0默认1升2降
    private ShopVO mShopVO;


    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.shop_list_activity);
    }

    @Override
    public void initView() {
        mSwipeRefresh = getViewById(R.id.swipe_refresh_layout);
        mLuRecyclerView = getViewById(R.id.recycler_view);
        mLuRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mLuRecyclerView.addItemDecoration(DividerUtil.linnerDivider(this, R.dimen.dp_1, R.color.C3));
        mAdapter = new ShopListRadapter(mLuRecyclerView);
        LuRecyclerViewAdapter adapter = new LuRecyclerViewAdapter(mAdapter);
        mLuRecyclerView.setAdapter(adapter);
        mPriceTv = getViewById(R.id.price_tv);
    }

    @Override
    public void bindViewsListener() {

    }

    @Override
    public BaseVO getData() {
        RequestParams paramsMap = new RequestParams();
        String mUrl = Constant.SHOP_LIST_URL;
        paramsMap.put("key", AppApplication.getInstance().getUserInfoVO().getKey());
        return HttpClientUtil.getRequest(mActivity, this, mUrl, paramsMap, ShopVO.class);
    }

    @Override
    public void hasData(BaseVO vo) {
        ShopVO shopVO= (ShopVO) vo;
        mShopVO=shopVO.getDatas();
        mAdapter.updateData(mShopVO.getGoods_list());
    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.price_tv:
                if (mPriceType == 0) {
//                    mPriceTv.setCompoundDrawables(0,0,R.drawable.shop_list_low_sort,0);
                } else if (mPriceType == 1) {

                } else {

                }
                break;
            default:
                break;
        }
    }
}
