package com.xiaojing.shop.activity;

import android.os.Bundle;
import android.app.Activity;

import com.xiaojing.shop.R;

public class CityActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.city_activity);
    }

}
