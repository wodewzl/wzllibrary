package com.xiaojing.shop.fragment;

import android.support.v4.content.ContextCompat;
import android.support.v7.widget.GridLayoutManager;
import android.view.View;

import com.github.jdsjlzx.ItemDecoration.SpacesItemDecoration;
import com.github.jdsjlzx.recyclerview.LRecyclerView;
import com.github.jdsjlzx.recyclerview.LRecyclerViewAdapter;
import com.wuzhanglong.library.fragment.BaseFragment;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.view.AutoSwipeRefreshLayout;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.OneShopRAdapter1;

public class OneShopFragment2 extends BaseFragment {
    private AutoSwipeRefreshLayout mAutoSwipeRefreshLayout;
    private LRecyclerView mRecyclerView;
    private OneShopRAdapter1 mOneShopRAdapter1;
    public static BaseFragment newInstance() {
        BaseFragment fragment = new OneShopFragment2();
//        Bundle args = new Bundle();
//        args.putString(ARG_PARAM1, param1);
//        args.putString(ARG_PARAM2, param2);
//        fragment.setArguments(args);
        return fragment;
    }
    @Override
    public void getData() {
        showView();
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    @Override
    public void setContentView() {
        contentInflateView(R.layout.one_shop_fragment1);
    }

    @Override
    public void initView(View view) {

//        mAutoSwipeRefreshLayout=getViewById(R.id.swipe_refresh_layout);
//        mActivity.setSwipeRefreshLayoutColors(mAutoSwipeRefreshLayout);
        mRecyclerView=getViewById(R.id.recycler_view);

        mRecyclerView.setLayoutManager(new GridLayoutManager(mActivity,2));
//        mRecyclerView.setLayoutManager(new LinearLayoutManager(mActivity));
        mOneShopRAdapter1= new OneShopRAdapter1(mRecyclerView);
        LRecyclerViewAdapter adapter= new LRecyclerViewAdapter(mOneShopRAdapter1);
        mRecyclerView.setAdapter(adapter);

        int spacing = getResources().getDimensionPixelSize(R.dimen.dp_4);
        mRecyclerView.addItemDecoration(SpacesItemDecoration.newInstance(spacing, spacing, 2, ContextCompat.getColor(mActivity,R.color.C2)));

//        GridItemDecoration divider = new GridItemDecoration.Builder(mActivity)
//                .setHorizontal(R.dimen.dp_4)
//                .setVertical(R.dimen.dp_4)
//                .setColorResource(R.color.C7)
//                .build();
//        mRecyclerView.addItemDecoration(divider);
    }

    @Override
    public void bindViewsListener() {

    }
}
