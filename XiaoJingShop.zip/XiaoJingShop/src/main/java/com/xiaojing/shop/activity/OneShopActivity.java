package com.xiaojing.shop.activity;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;

import com.github.jdsjlzx.recyclerview.LRecyclerView;
import com.github.jdsjlzx.recyclerview.LRecyclerViewAdapter;
import com.wuzhanglong.library.ItemDecoration.DividerDecoration;
import com.wuzhanglong.library.ItemDecoration.StickyHeaderDecoration;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.DividerUtil;
import com.wuzhanglong.library.view.ScaleTransitionPagerTitleView;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.OneShopRAdapter;
import com.xiaojing.shop.fragment.OneShopFragment1;
import com.xiaojing.shop.fragment.OneShopFragment2;
import com.xiaojing.shop.fragment.OneShopFragment3;

import net.lucode.hackware.magicindicator.MagicIndicator;
import net.lucode.hackware.magicindicator.ViewPagerHelper;
import net.lucode.hackware.magicindicator.buildins.UIUtil;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;

import java.util.ArrayList;

public class OneShopActivity extends BaseActivity {
    private String[] mTitleDataList={"人气","进度","最新揭晓"};
    private ViewPager mViewPager;
    private ArrayList<Fragment> mFragmentList;
    private LRecyclerView mRecyclerView;
    private LRecyclerViewAdapter mLAdapter;
    private OneShopRAdapter mOneShopRAdapter;
    private StickyHeaderDecoration decor;
    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.one_shop_activity);
    }

    @Override
    public void initView() {
        mRecyclerView=getViewById(R.id.recycler_view);
//        mViewPager=getViewById(R.id.view_pager);
//        initMagicIndicator();



        mRecyclerView = getViewById(R.id.recycler_view);
//        mRecyclerView.setPullRefreshEnabled(false);
        DividerDecoration divider = DividerUtil.linnerDivider(this,R.dimen.dp_1,R.color.C3);
        mRecyclerView.addItemDecoration(divider);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mOneShopRAdapter  = new OneShopRAdapter(this);
        mLAdapter = new LRecyclerViewAdapter(mOneShopRAdapter);

//        CommonHeader headerView = new CommonHeader(this, R.layout.my_jingbi_head);

        mLAdapter.addHeaderView(initHeadView());
        decor = new StickyHeaderDecoration(mOneShopRAdapter);
        mRecyclerView.setAdapter(mLAdapter);
        mRecyclerView.addItemDecoration(decor, 1);
    }

    private void initMagicIndicator() {
        MagicIndicator magicIndicator = (MagicIndicator) findViewById(R.id.magic_indicator);
        magicIndicator.setBackgroundColor(Color.WHITE);
        CommonNavigator commonNavigator = new CommonNavigator(this);
        commonNavigator.setAdjustMode(true);
        commonNavigator.setAdapter(new CommonNavigatorAdapter() {
            @Override
            public int getCount() {
                return mTitleDataList == null ? 0 : mTitleDataList.length;
            }

            @Override
            public IPagerTitleView getTitleView(Context context, final int index) {
                SimplePagerTitleView simplePagerTitleView = new ScaleTransitionPagerTitleView(context);
                simplePagerTitleView.setText(mTitleDataList[index]);
                simplePagerTitleView.setTextSize(18);
                simplePagerTitleView.setNormalColor(Color.parseColor("#616161"));
                simplePagerTitleView.setSelectedColor(Color.parseColor("#f57c00"));
                simplePagerTitleView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        mViewPager.setCurrentItem(index);
                    }
                });
                return simplePagerTitleView;
            }

            @Override
            public IPagerIndicator getIndicator(Context context) {
                LinePagerIndicator indicator = new LinePagerIndicator(context);
                indicator.setStartInterpolator(new AccelerateInterpolator());
                indicator.setEndInterpolator(new DecelerateInterpolator(1.6f));
//                indicator.setYOffset(UIUtil.dip2px(context, 39));
                indicator.setLineHeight(UIUtil.dip2px(context, 2));
                indicator.setColors(Color.parseColor("#f57c00"));
//                LinePagerIndicator indicator = new LinePagerIndicator(context);
//                indicator.setColors(Color.parseColor("#40c4ff"));
                return indicator;
            }

            @Override
            public float getTitleWeight(Context context, int index) {
                if (index == 0) {
                    return 1.0f;
                } else if (index == 1) {
                    return 1.0f;
                } else {
                    return 1.0f;
                }
            }
        });

        initViewPagerData();
        magicIndicator.setNavigator(commonNavigator);
        ViewPagerHelper.bind(magicIndicator, mViewPager);
    }

    public void initViewPagerData(){
        mFragmentList=new ArrayList<>();
        mFragmentList.add(OneShopFragment1.newInstance());
        mFragmentList.add(OneShopFragment2.newInstance());
        mFragmentList.add(OneShopFragment3.newInstance());
        mViewPager.setAdapter(new FragmentPagerAdapter(getSupportFragmentManager()) {
            @Override
            public Fragment getItem(int position) {
                return mFragmentList.get(position);
            }

            @Override
            public int getCount() {
                return mFragmentList.size();
            }
        });

    }

    @Override
    public void bindViewsListener() {

    }

    @Override
    public void getData() {
        showView();
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }


    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public View  initHeadView(){
        View header = LayoutInflater.from(this).inflate(R.layout.one_shop_item_type1,(ViewGroup)findViewById(android.R.id.content), false);

        return header;
    }

}
