package com.xiaojing.shop.activity;

import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import com.wuzhanglong.library.ItemDecoration.DividerDecoration;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.DividerUtil;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.AddressRAdapter;

public class AddressActivity extends BaseActivity {
    private RecyclerView mRecyclerView;
    private AddressRAdapter mAadpter;

    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.address_activity);
    }

    @Override
    public void initView() {
        mRecyclerView = getViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mAadpter = new AddressRAdapter(mRecyclerView);
        mRecyclerView.setAdapter(mAadpter);
//        DividerDecoration divider = new DividerDecoration.Builder(mActivity)
//                .setHeight(R.dimen.dp_10)
//                .setColorResource(R.color.C3_1)
//                .build();
//        mRecyclerView.addItemDecoration(divider);
        DividerDecoration divider =DividerUtil.linnerDivider(this,R.dimen.dp_10,R.color.C3_1);
                mRecyclerView.addItemDecoration(divider);
    }

    @Override
    public void bindViewsListener() {

    }

    @Override
    public void getData() {
        showView();
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }


}
