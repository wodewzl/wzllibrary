package com.xiaojing.shop.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;

import com.wuzhanglong.library.adapter.RecyclerBaseAdapter;
import com.xiaojing.shop.R;
import com.xiaojing.shop.mode.CategoryVO;

import cn.bingoogolapple.androidcommon.adapter.BGAViewHolderHelper;

/**
 * Created by cheng on 16-11-10.
 */
public class AdapterLeftMenu  extends RecyclerBaseAdapter<CategoryVO> {

    public interface OnLeftSelectedListener{
        public void onLeftItemSelected( CategoryVO menu);
    }
    private CategoryVO mSelectVO;
    public OnLeftSelectedListener listener;


    public AdapterLeftMenu(RecyclerView recyclerView) {
        super(recyclerView, R.layout.left_menu_item);
    }

    @Override
    public void initData(final BGAViewHolderHelper helper, int position, Object model) {
        final CategoryVO vo= (CategoryVO) model;
        helper.setText(R.id.left_menu_textview,vo.getGc_name());
        final LinearLayout leftMenu= (LinearLayout) helper.getConvertView();
        if(mSelectVO==null && position==0){
            mSelectVO=vo;
            vo.setSelect(true);
            helper.setVisibility(R.id.left_view,View.VISIBLE);
            leftMenu.setBackgroundColor(mContext.getResources().getColor(R.color.C3));
        }


        if(vo.isSelect()){
            helper.setVisibility(R.id.left_view,View.VISIBLE);
            helper.setBackgroundColorRes(R.id.left_menu_textview,R.color.C3);
        }else{
            helper.setVisibility(R.id.left_view,View.GONE);
            helper.setBackgroundColorRes(R.id.left_menu_textview,R.color.C1);
        }

        leftMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mSelectVO!=null)
                    mSelectVO.setSelect(false);
                mSelectVO=vo;
                mSelectVO.setSelect(true);
                if(mSelectVO.isSelect()){

                    helper.setVisibility(R.id.left_view,View.VISIBLE);
                    helper.setBackgroundColorRes(R.id.left_menu_textview,R.color.C3);
                }else{
                    helper.setVisibility(R.id.left_view,View.GONE);
                    helper.setBackgroundColorRes(R.id.left_menu_textview,R.color.C1);
                }
                notifyDataSetChanged();
                listener.onLeftItemSelected(vo);
            }
        });

    }

    public void setListener(OnLeftSelectedListener listener) {
        this.listener = listener;
    }

    public OnLeftSelectedListener getListener() {
        return listener;
    }

//    @Override
//    public int getItemCount() {
//        return 15;
//    }
//
//    @Override
//    public int getItemViewType(int position) {
//        return R.layout.history_shop_adapter;
//    }
//
//
//
//
//
//
//
//    private Context mContext;
//    private List<CategoryVO> mMenuList;
//    private int mSelectedNum;
//    private List<onItemSelectedListener> mSelectedListenerList;
//
//    public interface onItemSelectedListener{
//        public void onLeftItemSelected(int postion, CategoryVO menu);
//    }
//
//    public void addItemSelectedListener(onItemSelectedListener listener){
//        if(mSelectedListenerList!=null)
//            mSelectedListenerList.add(listener);
//    }
//
//    public void removeItemSelectedListener(onItemSelectedListener listener){
//        if(mSelectedListenerList!=null && !mSelectedListenerList.isEmpty())
//            mSelectedListenerList.remove(listener);
//    }
//
//    public AdapterLeftMenu(Context mContext, List<CategoryVO> mMenuList){
//        this.mContext = mContext;
//        this.mMenuList = mMenuList;
//        this.mSelectedNum = -1;
//        this.mSelectedListenerList = new ArrayList<>();
//        if(mMenuList.size()>0)
//            mSelectedNum = 0;
//    }
//
//    @Override
//    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
//        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.left_menu_item, parent, false);
//        LeftMenuViewHolder viewHolder = new LeftMenuViewHolder(view);
//        return viewHolder;
//    }
//
//    @Override
//    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
//        CategoryVO dishMenu = mMenuList.get(position);
//        LeftMenuViewHolder viewHolder = (LeftMenuViewHolder)holder;
//        viewHolder.menuName.setText(dishMenu.getName());
//        if(mSelectedNum==position){
//            viewHolder.menuLayout.setSelected(true);
//        }else{
//            viewHolder.menuLayout.setSelected(false);
//        }
//    }
//
//    @Override
//    public int getItemCount() {
//        return mMenuList.size();
//    }
//
//    public void setSelectedNum(int selectedNum) {
//        if(selectedNum<getItemCount() && selectedNum>=0 ) {
//            this.mSelectedNum = selectedNum;
//            notifyDataSetChanged();
//        }
//    }
//
//    public int getSelectedNum() {
//        return mSelectedNum;
//    }
//
//    private class LeftMenuViewHolder extends RecyclerView.ViewHolder{
//
//        TextView menuName;
//        LinearLayout menuLayout;
//
//        public LeftMenuViewHolder(final View itemView) {
//            super(itemView);
//            menuName = (TextView)itemView.findViewById(R.id.left_menu_textview);
//            menuLayout = (LinearLayout)itemView.findViewById(R.id.left_menu_item);
//            menuLayout.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View view) {
//                    int clickPosition = getAdapterPosition();
////                    setSelectedNum(clickPosition);
//                    notifyItemSelected(clickPosition);
//                }
//            });
//        }
//    }
//
//    private void notifyItemSelected(int position) {
//        if(mSelectedListenerList!=null && !mSelectedListenerList.isEmpty()){
//            for(onItemSelectedListener listener:mSelectedListenerList){
//                listener.onLeftItemSelected(position,mMenuList.get(position));
//            }
//        }
//    }
}
