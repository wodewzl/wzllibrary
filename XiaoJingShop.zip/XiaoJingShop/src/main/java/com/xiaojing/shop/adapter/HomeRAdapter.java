package com.xiaojing.shop.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;
import com.wuzhanglong.library.adapter.RecyclerBaseAdapter;
import com.xiaojing.shop.R;
import com.xiaojing.shop.mode.HomeVO;
import com.youth.banner.Banner;
import com.youth.banner.BannerConfig;
import com.youth.banner.loader.ImageLoader;

import java.util.ArrayList;
import java.util.List;

import cn.bingoogolapple.androidcommon.adapter.BGAViewHolderHelper;

/**
 * Created by Administrator on 2017/2/13.
 */

public class HomeRAdapter extends RecyclerBaseAdapter<HomeVO> {
    public HomeRAdapter(RecyclerView recyclerView) {
        super(recyclerView, R.layout.home_adapter);
    }

    @Override
    public void initData(BGAViewHolderHelper helper, int position, Object model) {
//        helper.setText(R.id.name,"我草草草");

        switch (position) {
            case 0:
                Banner banner=helper.getView(R.id.banner);
                banner.setBannerStyle(BannerConfig.CIRCLE_INDICATOR);
                banner.setImageLoader(new ImageLoader() {
                    @Override
                    public void displayImage(Context context, Object o, ImageView imageView) {
                        Picasso.with(context).load((String) o).into(imageView);
                    }

                });
                List<String> images = new ArrayList<>();
                images.add("https://ss2.baidu.com/-vo3dSag_xI4khGko9WTAnF6hhy/super/whfpf%3D425%2C260%2C50/sign=a4b3d7085dee3d6d2293d48b252b5910/0e2442a7d933c89524cd5cd4d51373f0830200ea.jpg");
                images.add("https://ss0.baidu.com/-Po3dSag_xI4khGko9WTAnF6hhy/super/whfpf%3D425%2C260%2C50/sign=a41eb338dd33c895a62bcb3bb72e47c2/5fdf8db1cb134954a2192ccb524e9258d1094a1e.jpg");
                images.add("http://c.hiphotos.baidu.com/image/w%3D400/sign=c2318ff84334970a4773112fa5c8d1c0/b7fd5266d0160924c1fae5ccd60735fae7cd340d.jpg");


                banner.setIndicatorGravity(BannerConfig.CENTER);
                banner.setImages(images);
                banner.start();
            break;
            case 1:

            break;
            case 2:

            break;
            case 3:

            break;
            case 4:

            break;

        }
    }

    @Override
    public int getItemCount() {
        return 5;
    }

        @Override
    public int getItemViewType(int position) {
            if(position==0){
                return R.layout.home_adapter_type0;
            }else if(position==1){
                return R.layout.home_adapter_type1;
            }else if(position==2){
                return R.layout.home_adapter_type2;
            }else if(position==3){
                return R.layout.home_adapter_type3;
            }else {
                return R.layout.home_adapter_type4;
            }

    }

    //    public HomeRAdapter(RecyclerView recyclerView) {
//        super(recyclerView, R.layout.home_adapter);
//    }
//
//    @Override
//    protected void fillData(BGAViewHolderHelper helper, int position, HomeVO model) {
//
//    }


//    private LayoutInflater mLayoutInflater;
//    public HomeRAdapter(Context context) {
////        mLayoutInflater = LayoutInflater.from(context);
//        mContext = context;
//    }
//
//    @Override
//    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
////        return new ViewHolder(mLayoutInflater.inflate(R.layout.sample_item_text, parent, false));
//        return new ViewHolder(View.inflate(mContext, R.layout.home_adapter,null));
//    }
//
//    @Override
//    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
//        HomeVO item = mList.get(position);
//
//        ViewHolder viewHolder = (ViewHolder) holder;
////        viewHolder.textView.setText(item.title);
//    }
//
//
//    private class ViewHolder extends RecyclerView.ViewHolder {
//
//        private TextView textView;
//
//        public ViewHolder(View itemView) {
//            super(itemView);
////            textView = (TextView) itemView.findViewById(R.id.info_text);
//        }
//    }

}
