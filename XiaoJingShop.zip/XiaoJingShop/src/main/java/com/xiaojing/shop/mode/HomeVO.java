package com.xiaojing.shop.mode;

/**
 * Created by Administrator on 2017/2/13.
 */

public class HomeVO {
    private String title;

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
