package com.xiaojing.shop.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.wuzhanglong.library.ItemDecoration.StickyHeaderAdapter;
import com.wuzhanglong.library.adapter.LRecyclerBaseAdapter;
import com.xiaojing.shop.R;
import com.xiaojing.shop.mode.CategoryVO;

/**
 * Created by Administrator on 2017/2/13.
 */

public class MyJBAdapter extends LRecyclerBaseAdapter<CategoryVO> implements
        StickyHeaderAdapter<MyJBAdapter.HeaderHolder> {
    private LayoutInflater mInflater;
    private Context mContext;

    public MyJBAdapter(Context context) {
        mContext = context;
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        final View view = mInflater.inflate(R.layout.my_jingbi_adapter_type1, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        super.onBindViewHolder(holder, position);
    }

    @Override
    public long getHeaderId(int position) {
        //原理是这样的 11112222333334444444 同样字段是一组
        if (position > 0) {
            return 1;
        } else {
            return 2;
        }

    }

    @Override
    public int getItemCount() {
        return 15;
    }

    @Override
    public HeaderHolder onCreateHeaderViewHolder(ViewGroup parent) {
        final View view = mInflater.inflate(R.layout.my_jingbi_adapter_type2, parent, false);
        return new HeaderHolder(view);
    }

    @Override
    public void onBindHeaderViewHolder(final HeaderHolder viewholder, final int position) {
//        viewholder.header.setText("Header " + getHeaderId(position));
        viewholder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(mContext, "onBindHeaderViewHolder item clicked position = " + position, Toast.LENGTH_SHORT).show();
            }
        });
        if (getHeaderId(position) == 2) {
            viewholder.header.setVisibility(View.GONE);
        } else {
            viewholder.header.setVisibility(View.VISIBLE);

        }
    }


    static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView item;

        public ViewHolder(View itemView) {
            super(itemView);
//            item = (TextView) itemView;
        }
    }

    static class HeaderHolder extends RecyclerView.ViewHolder {
        public TextView header;

        public HeaderHolder(View itemView) {
            super(itemView);
            header = (TextView) itemView.findViewById(R.id.header);
        }
    }

}
