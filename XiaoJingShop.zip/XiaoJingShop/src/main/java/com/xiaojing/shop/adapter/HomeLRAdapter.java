package com.xiaojing.shop.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.wuzhanglong.library.ItemDecoration.StickyHeaderAdapter;
import com.wuzhanglong.library.adapter.LRecyclerBaseAdapter;
import com.xiaojing.shop.R;
import com.xiaojing.shop.mode.CategoryVO;

/**
 * Created by Administrator on 2017/2/13.
 */

public class HomeLRAdapter extends LRecyclerBaseAdapter<CategoryVO> implements
        StickyHeaderAdapter<HomeLRAdapter.HeaderHolder> {


    private LayoutInflater mInflater;
    private Context mContext;

    public HomeLRAdapter(Context context) {
        mContext = context;
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        final View view = mInflater.inflate(R.layout.right_dish_item1, viewGroup, false);

        return new ViewHolder(view);
    }



    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        super.onBindViewHolder(holder, position);
    }

    @Override
    public long getHeaderId(int position) {
//        System.out.println("=====================>>>>>getParent_id(): "+mList.get(position).getParent_id());
//        return Integer.parseInt(mList.get(position).getParent_id());
        if(position<=7){
            return 1;
        }else if(position>7&&position<=14){
            return 2;
        }else{
            return 3;
        }
    }

    @Override
    public HeaderHolder onCreateHeaderViewHolder(ViewGroup parent) {
        final View view = mInflater.inflate(R.layout.right_menu_item, parent, false);
        return new HeaderHolder(view);
    }

    @Override
    public void onBindHeaderViewHolder(final HeaderHolder viewholder, final int position) {
//        viewholder.header.setText("Header " + getHeaderId(position));
        viewholder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(mContext,"onBindHeaderViewHolder item clicked position = " + position,Toast.LENGTH_SHORT).show();
            }
        });
    }


    static class ViewHolder extends RecyclerView.ViewHolder {
        public TextView item;

        public ViewHolder(View itemView) {
            super(itemView);

//            item = (TextView) itemView;
        }
    }

    static class HeaderHolder extends RecyclerView.ViewHolder {
        public TextView header;
        public HeaderHolder(View itemView) {
            super(itemView);
//            header = (TextView) itemView;
        }
    }

}
