package com.xiaojing.shop.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;

import com.wuzhanglong.library.adapter.ListBaseAdapter;
import com.wuzhanglong.library.utils.ToastUtil;
import com.xiaojing.shop.R;

import cn.bingoogolapple.androidcommon.adapter.BGAOnItemChildClickListener;
import cn.bingoogolapple.androidcommon.adapter.BGAViewHolderHelper;


/**
 * Created by Administrator on 2017/2/13.
 */

public class HomeAdapter extends ListBaseAdapter {
    public HomeAdapter(Context context) {
        super(context, R.layout.home_adapter);
    }

    @Override
    public void initData(BGAViewHolderHelper helper, int position, Object model) {
        helper.setText(R.id.name,"我草草草");
        helper.setOnItemChildClickListener(new BGAOnItemChildClickListener() {
            @Override
            public void onItemChildClick(ViewGroup parent, View childView, int position) {
                ToastUtil.show("大咪咪,你在干嘛");
            }
        });

    }

    //    public HomeAdapter(Context context) {
//            super(context);
//    }
//    @SuppressLint("NewApi")
//    @Override
//    public View getView(int position, View convertView, ViewGroup parent) {
////        return super.getView(arg0, convertView, arg2);
//        final ViewHolder holder;
//        if (mIsEmpty) {
//            return super.getView(position, convertView, parent);
//        }
//
//        if (convertView != null && convertView.getTag() == null)
//            convertView = null;
//
//        if (convertView == null ) {
//            holder = new ViewHolder();
//            convertView = View.inflate(mContext, R.layout.home_adapter, null);
//            holder.ratingBar= (RatingBar) convertView.findViewById(R.id.rating_bar);
//            holder.newBg= (TextView) convertView.findViewById(R.id.new_bg);
//            convertView.setTag(holder);
//        } else {
//            holder = (ViewHolder) convertView.getTag();
//
//        }
//        LayerDrawable ld= (LayerDrawable) holder.ratingBar.getProgressDrawable();
//        ld.getDrawable(2).setColorFilter(mContext.getResources().getColor(R.color.C10), PorterDuff.Mode.SRC_ATOP);
//
//       holder.newBg.setBackground( BaseCommonUtils.setBackgroundShap(mContext,5,R.color.C12,R.color.C12));
//        return convertView;
//    }
//
//     class ViewHolder {
//        private TextView newBg, titleContentTv, timeTv, rewardTv, statusTv;
//         private RatingBar ratingBar;
//    }


}
