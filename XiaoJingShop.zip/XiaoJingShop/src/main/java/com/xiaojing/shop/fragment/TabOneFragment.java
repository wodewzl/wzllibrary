package com.xiaojing.shop.fragment;


import android.graphics.Color;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.LinearLayout;

import com.github.jdsjlzx.interfaces.OnLoadMoreListener;
import com.github.jdsjlzx.interfaces.OnRefreshListener;
import com.loopj.android.http.RequestParams;
import com.wuzhanglong.library.fragment.BaseFragment;
import com.wuzhanglong.library.http.HttpClientUtil;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.BaseCommonUtils;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.HomeRAdapter;
import com.xiaojing.shop.constant.Constant;
import com.xiaojing.shop.mode.CategoryVO;

/**
 * Created by Administrator on 2017/2/9.
 */

public class TabOneFragment extends BaseFragment implements OnLoadMoreListener, OnRefreshListener {
    RequestParams mParamsMap = new RequestParams();
    private RecyclerView mRecyclerView;
    private HomeRAdapter mRAdapter;
    private LinearLayout mTitleLayout;
    private int mDistanceY;

    @Override
    public void setContentView() {
        contentInflateView(R.layout.tab_one_fragment);
    }


    @Override
    public void initView(View view) {
        mTitleLayout= (LinearLayout) view.findViewById(R.id.title_view);
        mRecyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mActivity));
        mRAdapter = new HomeRAdapter(mRecyclerView);
        mRecyclerView.setAdapter(mRAdapter);
        mActivity.showProgressDialog();
    }


    @Override
    public void bindViewsListener() {
//        mRecyclerView.setOnLoadMoreListener(this);
//        mRecyclerView.setOnRefreshListener(this);


        //        view.findViewById(R.id.tv).setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                mActivity.openActivity(ImagePublishActivity.class);
//                mActivity.openActivity(SelefActivity.class);
//                mActivity.openActivity(DemoActivity.class);
//                mActivity.openActivity(RegistActivity.class);
//            }
//        });


        /**
         * 滑动标题栏渐变
         */
        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                //滑动的距离
                mDistanceY += dy;
                //toolbar的高度
//                int toolbarHeight = mTitleLayout.getBottom();
                int toolbarHeight=BaseCommonUtils.dip2px(mActivity,175);
                //当滑动的距离 <= toolbar高度的时候，改变Toolbar背景色的透明度，达到渐变的效果
                if (mDistanceY <= toolbarHeight) {
                    float scale = (float) mDistanceY / toolbarHeight;
                    float alpha = scale * 255;
                    mTitleLayout.setBackgroundColor(Color.argb((int) alpha, 0, 153, 223));
//                    RxAnimationUtils.animationColorGradient(R.color.C15, R.color.C7, new onUpdateListener() {
//                        @Override
//                        public void onUpdate(int i) {
//
//                        }
//                    });
                } else {
                    //将标题栏的颜色设置为完全不透明状态
                    mTitleLayout.setBackgroundResource(R.color.C7);
                }
            }
        });


    }


    @Override
    public void getData() {
//        System.out.println("============================>");

//        showView();
mActivity.showProgressDialog();
                RequestParams paramsMap = new RequestParams();
        String mUrl = Constant.CATEGORY_URL;
        HttpClientUtil.get(mActivity, this, mUrl, paramsMap, CategoryVO.class);
    }

    @Override
    public void hasData(BaseVO vo) {
//        mActivity.dismissProgressDialog();
        System.out.println("===================>>>>>>>>1");
//        if (BaseCommonUtils.parseInt(mNewsVO.getTotal()) > BaseCommonUtils.parseInt(mNewsVO
// .getPage())) {
//            mListView.showFooterView(true);
//        } else {
//            mListView.showFooterView(false);
//        }
//        mListView.showFooterView(true);
    }

    @Override
    public void noData(BaseVO vo) {
        System.out.println("===================>>>>>>>>2");
    }

    @Override
    public void noNet() {
        System.out.println("===================>>>>>>>>3");
    }


    @Override
    public void onLoadMore() {

    }

    @Override
    public void onRefresh() {

    }



}
