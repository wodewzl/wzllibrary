package com.xiaojing.shop.activity;

import android.annotation.TargetApi;
import android.os.Build;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.github.jdsjlzx.recyclerview.LuRecyclerView;
import com.github.jdsjlzx.recyclerview.LuRecyclerViewAdapter;
import com.rey.material.widget.TextView;
import com.wuzhanglong.library.ItemDecoration.DividerDecoration;
import com.wuzhanglong.library.ItemDecoration.StickyHeaderDecoration;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.BaseCommonUtils;
import com.wuzhanglong.library.utils.DividerUtil;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.MyOverAdapter;

public class MyOverActivity extends BaseActivity {
    private TextView mWithdrawTv,mRechargeTv;
    private LuRecyclerView mRecyclerView;
    private MyOverAdapter myOverAdapter;
    private StickyHeaderDecoration decor;
    private LuRecyclerViewAdapter mLuAdapter;
    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.my_over_activity);
    }

    @Override
    public void initView() {
        mRecyclerView = getViewById(R.id.recycler_view);
//        mRecyclerView.setPullRefreshEnabled(false);
        DividerDecoration divider = DividerUtil.linnerDivider(this,R.dimen.dp_1,R.color.C3);
        mRecyclerView.addItemDecoration(divider);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        myOverAdapter = new MyOverAdapter(this);
        mLuAdapter = new LuRecyclerViewAdapter(myOverAdapter);

//        CommonHeader headerView = new CommonHeader(this, R.layout.my_jingbi_head);

        mLuAdapter.addHeaderView(initHeadView());
        decor = new StickyHeaderDecoration(myOverAdapter);
        mRecyclerView.setAdapter(mLuAdapter);
        mRecyclerView.addItemDecoration(decor, 1);
    }

    @Override
    public void bindViewsListener() {

    }

    @Override
    public void getData() {
        showView();
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public View  initHeadView(){
        View header = LayoutInflater.from(this).inflate(R.layout.my_over_head,(ViewGroup)findViewById(android.R.id.content), false);

        mRechargeTv = (TextView) header.findViewById(R.id.recharge_tv);
        mWithdrawTv= (TextView) header.findViewById(R.id.withdraw_tv);

        mRechargeTv.setBackground(BaseCommonUtils.setBackgroundShap(this,50,R.color.XJColor6,R.color.C1));
        mWithdrawTv.setBackground(BaseCommonUtils.setBackgroundShap(this,100,R.color.XJColor6,R.color.C1));


        return header;
    }

}
