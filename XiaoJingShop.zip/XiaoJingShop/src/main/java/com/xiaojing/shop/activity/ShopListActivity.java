package com.xiaojing.shop.activity;

import android.support.v7.widget.LinearLayoutManager;
import android.view.View;

import com.github.jdsjlzx.recyclerview.LuRecyclerView;
import com.github.jdsjlzx.recyclerview.LuRecyclerViewAdapter;
import com.rey.material.widget.TextView;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.DividerUtil;
import com.wuzhanglong.library.view.AutoSwipeRefreshLayout;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.ShopListRadapter;

public class ShopListActivity extends BaseActivity implements View.OnClickListener{
    private LuRecyclerView mLuRecyclerView;
    private AutoSwipeRefreshLayout mSwipeRefresh;
    private ShopListRadapter mAdapter;
    private TextView mPriceTv;
    private int mPriceType=0;//0默认1升2降


    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.shop_list_activity);
    }

    @Override
    public void initView() {
        mSwipeRefresh = getViewById(R.id.swipe_refresh_layout);
        mLuRecyclerView = getViewById(R.id.recycler_view);
        mLuRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mLuRecyclerView.addItemDecoration(DividerUtil.linnerDivider(this, R.dimen.dp_1, R.color.C3));
        mAdapter = new ShopListRadapter(mLuRecyclerView);
        LuRecyclerViewAdapter adapter = new LuRecyclerViewAdapter(mAdapter);
        mLuRecyclerView.setAdapter(adapter);
        mPriceTv=getViewById(R.id.price_tv);

    }

    @Override
    public void bindViewsListener() {

    }

    @Override
    public void getData() {
        showView();
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.price_tv:
                if(mPriceType==0){
//                    mPriceTv.setCompoundDrawables(0,0,R.drawable.shop_list_low_sort,0);
                }else if(mPriceType==1){

                }else{

                }
                break;
            default:
                break;
        }
    }
}
