package com.xiaojing.shop.fragment;

import android.content.Intent;
import android.net.Uri;
import android.support.v4.app.ActivityCompat;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;

import com.rey.material.widget.TextView;
import com.squareup.picasso.Picasso;
import com.vondear.rxtools.RxImageUtils;
import com.vondear.rxtools.RxPhotoUtils;
import com.vondear.rxtools.RxSPUtils;
import com.vondear.rxtools.view.dialog.RxDialogChooseImage;
import com.wuzhanglong.library.fragment.BaseFragment;
import com.wuzhanglong.library.mode.BaseVO;
import com.xiaojing.shop.R;
import com.xiaojing.shop.activity.MyJingBiActivity;
import com.xiaojing.shop.activity.MyOverActivity;
import com.xiaojing.shop.activity.OrderActivity;
import com.yalantis.ucrop.UCrop;
import com.yalantis.ucrop.UCropActivity;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;
import q.rorbin.badgeview.QBadgeView;

import static android.app.Activity.RESULT_OK;
import static com.vondear.rxtools.view.dialog.RxDialogChooseImage.LayoutType.NO_TITLE;
import static com.wuzhanglong.library.http.NetWorkHelper.uri;


/**
 * Created by Administrator on 2017/2/9.
 */

public class TabFourFragment extends BaseFragment implements View.OnClickListener, View.OnLongClickListener {
    private TextView mTextView02;
    private View mHeadLayout;
    private CircleImageView mHeadImg;
    private Uri resultUri;
    private LinearLayout mJinDouLayout, mJinBiLayout, mOverLayout;
    private com.rey.material.widget.LinearLayout mOrderLayout;


    @Override
    public void setContentView() {
        View.inflate(mActivity, R.layout.tab_four_fragment, mBaseContentLayout);
    }

    @Override
    public void initView(View view) {
        mTextView02 = getViewById(R.id.textview_02);
        mHeadImg = getViewById(R.id.head_img);
        new QBadgeView(mActivity).bindTarget(mTextView02).setBadgeNumber(5).setBadgeGravity(Gravity.END | Gravity.TOP).setShowShadow(true).setGravityOffset(15, 0, true);
        mOrderLayout=getViewById(R.id.order_layout);

        mJinDouLayout = getViewById(R.id.jindou_layout);
        mJinBiLayout = getViewById(R.id.jinbi_layout);
        mOverLayout = getViewById(R.id.over_layout);
    }


    @Override
    public void bindViewsListener() {
        mHeadImg.setOnClickListener(this);
        mHeadImg.setOnLongClickListener(this);
        mJinDouLayout.setOnClickListener(this);
        mJinBiLayout.setOnClickListener(this);
        mOverLayout.setOnClickListener(this);
        mOrderLayout.setOnClickListener(this);
    }

    @Override
    public void getData() {
//        showView();
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    private void initDialogChooseImage() {
        RxDialogChooseImage dialogChooseImage = new RxDialogChooseImage(mActivity, NO_TITLE);
        dialogChooseImage.getLayoutParams().gravity = Gravity.BOTTOM;
        dialogChooseImage.show();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.head_img:
                RxImageUtils.showBigImageView(mActivity, resultUri);
                break;
            case R.id.order_layout:
                mActivity.openActivity(OrderActivity.class);
                break;

            case R.id.jindou_layout:
                mActivity.openActivity(MyJingBiActivity.class);
                break;
            case R.id.jinbi_layout:
                mActivity.openActivity(MyJingBiActivity.class);
                break;
            case R.id.over_layout:
                mActivity.openActivity(MyOverActivity.class);
                break;
            default:
                break;
        }
    }

    @Override
    public boolean onLongClick(View view) {
        initDialogChooseImage();
        return false;
    }


    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode) {
            case RxPhotoUtils.GET_IMAGE_FROM_PHONE://选择相册之后的处理
                if (resultCode == RESULT_OK) {
                    initUCrop(data.getData());
                }

                break;
            case RxPhotoUtils.GET_IMAGE_BY_CAMERA://选择照相机之后的处理
                if (resultCode == RESULT_OK) {
                    initUCrop(RxPhotoUtils.imageUriFromCamera);
                }

                break;
            case RxPhotoUtils.CROP_IMAGE://普通裁剪后的处理
                Picasso.with(mActivity).load(uri).into(mHeadImg);
                break;

            case UCrop.REQUEST_CROP://UCrop裁剪之后的处理
                if (resultCode == RESULT_OK) {
                    resultUri = UCrop.getOutput(data);
                    roadImageView(resultUri, mHeadImg);
                    RxSPUtils.putContent(mActivity, "AVATAR", resultUri.toString());
                } else if (resultCode == UCrop.RESULT_ERROR) {
                    final Throwable cropError = UCrop.getError(data);
                }
                break;
            case UCrop.RESULT_ERROR://UCrop裁剪错误之后的处理
                final Throwable cropError = UCrop.getError(data);
                break;
            default:
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void initUCrop(Uri uri) {
        SimpleDateFormat timeFormatter = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.CHINA);
        long time = System.currentTimeMillis();
        String imageName = timeFormatter.format(new Date(time));
        Uri destinationUri = Uri.fromFile(new File(mActivity.getCacheDir(), imageName + ".jpeg"));
        UCrop.Options options = new UCrop.Options();
        //设置裁剪图片可操作的手势
        options.setAllowedGestures(UCropActivity.SCALE, UCropActivity.ROTATE, UCropActivity.ALL);
        //设置隐藏底部容器，默认显示
        //options.setHideBottomControls(true);
        //设置toolbar颜色
        options.setToolbarColor(ActivityCompat.getColor(mActivity, R.color.colorPrimary));
        //设置状态栏颜色
        options.setStatusBarColor(ActivityCompat.getColor(mActivity, R.color.colorPrimaryDark));

        //开始设置
        //设置最大缩放比例
        options.setMaxScaleMultiplier(5);
        //设置图片在切换比例时的动画
        options.setImageToCropBoundsAnimDuration(666);
        //设置裁剪窗口是否为椭圆
//        options.setOvalDimmedLayer(true);
        //设置是否展示矩形裁剪框
//        options.setShowCropFrame(false);
        //设置裁剪框横竖线的宽度
//        options.setCropGridStrokeWidth(20);
        //设置裁剪框横竖线的颜色
//        options.setCropGridColor(Color.GREEN);
        //设置竖线的数量
//        options.setCropGridColumnCount(2);
        //设置横线的数量
//        options.setCropGridRowCount(1);

        UCrop.of(uri, destinationUri)
                .withAspectRatio(1, 1)
                .withMaxResultSize(1000, 1000)
                .withOptions(options)
                .start(mActivity);
    }

    //从Uri中加载图片 并将其转化成File文件返回
    private File roadImageView(Uri uri, CircleImageView imageView) {
        Picasso.with(mActivity).load(uri).into(imageView);
        return (new File(RxPhotoUtils.getImageAbsolutePath(mActivity, uri)));
    }


}
