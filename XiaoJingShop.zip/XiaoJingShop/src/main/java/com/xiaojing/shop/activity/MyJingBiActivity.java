package com.xiaojing.shop.activity;

import android.annotation.TargetApi;
import android.graphics.Color;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.LinearLayoutManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.github.jdsjlzx.recyclerview.LuRecyclerView;
import com.github.jdsjlzx.recyclerview.LuRecyclerViewAdapter;
import com.loopj.android.http.RequestParams;
import com.vondear.rxtools.view.tooltips.RxToolTip;
import com.vondear.rxtools.view.tooltips.RxToolTipsManager;
import com.wuzhanglong.library.ItemDecoration.DividerDecoration;
import com.wuzhanglong.library.ItemDecoration.StickyHeaderDecoration;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.http.HttpClientUtil;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.BaseCommonUtils;
import com.wuzhanglong.library.utils.DividerUtil;
import com.wuzhanglong.library.view.AutoSwipeRefreshLayout;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.MyJBAdapter;
import com.xiaojing.shop.constant.Constant;
import com.xiaojing.shop.mode.CategoryVO;

public class MyJingBiActivity extends BaseActivity implements RxToolTipsManager.TipListener,View.OnClickListener {
    RxToolTipsManager mRxToolTipsManager;
    private TextView mAllTv,mFreezeTv;
    private com.rey.material.widget.TextView mShopTv;
    private RelativeLayout mRootLayout;
    int mAlign = RxToolTip.ALIGN_CENTER;

    private AutoSwipeRefreshLayout mAutoSwipeRefreshLayout;
    private LuRecyclerView mRecyclerView;
    private MyJBAdapter mMyJBAdapter;
    private StickyHeaderDecoration decor;
    private LuRecyclerViewAdapter mLuAdapter;

    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.my_jing_bi_activity);
    }

    @Override
    public void initView() {

        mRecyclerView = getViewById(R.id.recycler_view);
//        mRecyclerView.setPullRefreshEnabled(false);
        DividerDecoration divider = DividerUtil.linnerDivider(this,R.dimen.dp_1,R.color.C3);
        mRecyclerView.addItemDecoration(divider);
        mRecyclerView.setHasFixedSize(true);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        mMyJBAdapter = new MyJBAdapter(this);
        mLuAdapter = new LuRecyclerViewAdapter(mMyJBAdapter);

//        CommonHeader headerView = new CommonHeader(this, R.layout.my_jingbi_head);

        mLuAdapter.addHeaderView(initHeadView());
        decor = new StickyHeaderDecoration(mMyJBAdapter);
        mRecyclerView.setAdapter(mLuAdapter);
        mRecyclerView.addItemDecoration(decor, 1);
//        getData();
    }

    @Override
    public void bindViewsListener() {
//        mAllTv.setOnClickListener(this);
//        mFreezeTv.setOnClickListener(this);
    }



    @Override
    public void getData() {
//        showView();

        RequestParams paramsMap = new RequestParams();
        String mUrl = Constant.CATEGORY_URL;
        HttpClientUtil.get(mActivity, MyJingBiActivity.this, mUrl, paramsMap, CategoryVO.class);


    }

    @Override
    public void hasData(BaseVO vo) {
        dismissProgressDialog();
    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    public View  initHeadView(){
        View header = LayoutInflater.from(this).inflate(R.layout.my_jingbi_head,(ViewGroup)findViewById(android.R.id.content), false);

        mAllTv = (TextView) header.findViewById(R.id.all_tv);
        mFreezeTv= (TextView) header.findViewById(R.id.freeze_tv);
        mShopTv= (com.rey.material.widget.TextView) header.findViewById(R.id.shop_tv);
        mRootLayout = (RelativeLayout) header.findViewById(R.id.root_layout);
        mRxToolTipsManager = new RxToolTipsManager(this);

        mAllTv.setBackground(BaseCommonUtils.setBackgroundShap(this,100,R.color.XJColor4,R.color.XJColor4));
        mFreezeTv.setBackground(BaseCommonUtils.setBackgroundShap(this,100,R.color.XJColor5,R.color.XJColor5));
        mShopTv.setBackground(BaseCommonUtils.setBackgroundShap(this,50,R.color.XJColor6,R.color.C1));
        mAllTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RxToolTip.Builder builderAll;
                mRxToolTipsManager.findAndDismiss(mAllTv);
                builderAll = new RxToolTip.Builder(MyJingBiActivity.this, mAllTv, mRootLayout, "总鲸币：526", RxToolTip.POSITION_RIGHT_TO);
                builderAll.setBackgroundColor(Color.parseColor("#FBEEE5"));
                builderAll.setTextColor(ContextCompat.getColor(MyJingBiActivity.this,R.color.C5));
                mRxToolTipsManager.show(builderAll.build());
            }
        });

        mFreezeTv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RxToolTip.Builder builderFreeze;
                mRxToolTipsManager.findAndDismiss(mFreezeTv);
                builderFreeze = new RxToolTip.Builder(MyJingBiActivity.this, mFreezeTv, mRootLayout, "冻结鲸币：526", RxToolTip.POSITION_RIGHT_TO);
                builderFreeze.setBackgroundColor(Color.parseColor("#E0FdF9"));
                builderFreeze.setTextColor(ContextCompat.getColor(MyJingBiActivity.this,R.color.C5));
                mRxToolTipsManager.show(builderFreeze.build());
            }
        });

        mAllTv.postDelayed(new Runnable() {
            @Override
            public void run() {
                RxToolTip.Builder builderAll;
//                mRxToolTipsManager.findAndDismiss(mAllTv);
                builderAll = new RxToolTip.Builder(MyJingBiActivity.this, mAllTv, mRootLayout, "总鲸币：526", RxToolTip.POSITION_RIGHT_TO);
                builderAll.setBackgroundColor(Color.parseColor("#FBEEE5"));
                builderAll.setTextColor(ContextCompat.getColor(MyJingBiActivity.this,R.color.C5));
                mRxToolTipsManager.show(builderAll.build());

                RxToolTip.Builder builderFreeze;
                mRxToolTipsManager.findAndDismiss(mFreezeTv);
                builderFreeze = new RxToolTip.Builder(MyJingBiActivity.this, mFreezeTv, mRootLayout, "冻结鲸币：526", RxToolTip.POSITION_RIGHT_TO);
                builderFreeze.setBackgroundColor(Color.parseColor("#E0FdF9"));
                builderFreeze.setTextColor(ContextCompat.getColor(MyJingBiActivity.this,R.color.C5));
                mRxToolTipsManager.show(builderFreeze.build());
            }
        },500);
        return header;
    }

    @Override
    public void onTipDismissed(View view, int i, boolean b) {

    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.all_tv:




                break;
            default:
                break;
        }
    }


}
