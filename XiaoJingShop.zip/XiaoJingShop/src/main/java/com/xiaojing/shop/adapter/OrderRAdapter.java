package com.xiaojing.shop.adapter;

import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;

import com.wuzhanglong.library.adapter.RecyclerBaseAdapter;
import com.wuzhanglong.library.utils.BaseCommonUtils;
import com.xiaojing.shop.R;
import com.xiaojing.shop.mode.HomeVO;

import cn.bingoogolapple.androidcommon.adapter.BGAViewHolderHelper;

/**
 * Created by Administrator on 2017/2/13.
 */

public class OrderRAdapter extends RecyclerBaseAdapter<HomeVO> {
    public OrderRAdapter(RecyclerView recyclerView) {
        super(recyclerView, R.layout.order_adapter);
    }

    @RequiresApi(api = Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public void initData(BGAViewHolderHelper helper, int position, Object model) {
//        helper.setText(R.id.name,"我草草草");
//        SnapUpCountDownTimerView rushBuyCountDownTimerView =helper.getView(R.id.timer_view);
        TextView totalMoneyTv=helper.getView(R.id.total_money_tv);
        BaseCommonUtils.setTextThree(mContext,totalMoneyTv,"合计:"," ￥300 ","（含运费￥10.00）",R.color.C4,1.5f);
        TextView totalCountTv=helper.getView(R.id.total_count_tv);
        BaseCommonUtils.setTextThree(mContext,totalCountTv,"共:"," 1 ","件商品",R.color.C4,1.5f);

        TextView type01Tv=helper.getView(R.id.type_01_tv);
        type01Tv.setBackground(BaseCommonUtils.setBackgroundShap(mContext,5,R.color.XJColor2,R.color.C3));
    }

    @Override
    public int getItemCount() {
        return 15;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.order_adapter;
    }
}
