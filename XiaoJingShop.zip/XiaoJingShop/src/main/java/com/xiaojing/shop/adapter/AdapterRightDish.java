package com.xiaojing.shop.adapter;

import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;
import com.wuzhanglong.library.adapter.RecyclerBaseAdapter;
import com.xiaojing.shop.R;
import com.xiaojing.shop.mode.CategoryVO;

import cn.bingoogolapple.androidcommon.adapter.BGAViewHolderHelper;

/**
 * Created by cheng on 16-11-10.
 */
public class AdapterRightDish extends  RecyclerBaseAdapter<CategoryVO> {
    public AdapterRightDish(RecyclerView recyclerView) {
        super(recyclerView, R.layout.right_menu_item);
    }

    @Override
    public void initData(BGAViewHolderHelper helper, int position, Object model) {
        CategoryVO vo= (CategoryVO) model;
        if(vo.getGrandson() !=null){
            helper.setText(R.id.right_menu_tv,vo.getGc_name());
//            LinearLayout right_menu_item =helper.getView(R.id.right_menu_item);
           View view= helper.getConvertView();
            view.setContentDescription(position+"");
        }else{
            helper.setText(R.id.child_itme,vo.getGc_name());
            ImageView img=helper.getImageView(R.id.img);
                Picasso.with(mContext).load(vo.getGc_image()).into(img);
        }

    }

    @Override
    public int getItemViewType(int position) {
//        return super.getItemViewType(position);
        CategoryVO vo= (CategoryVO) mData.get(position);
        if(vo.getGrandson() !=null){
            return R.layout.right_menu_item;
        }else{
            return R.layout.right_dish_item1;
        }
    }

    //    private final int MENU_TYPE = 0;
//    private final int DISH_TYPE = 1;
//    private final int HEAD_TYPE = 2;
//
//    private Context mContext;
//    private ArrayList<CategoryVO> mMenuList;
////    private int mItemCount;
//   public ImageLoader mImageLoader;
//    public DisplayImageOptions mOptions;
//
//    public AdapterRightDish(Context mContext, ArrayList<CategoryVO> mMenuList){
//        this.mContext = mContext;
//        this.mMenuList = mMenuList;
////        this.mItemCount = mMenuList.size();
//        mOptions = Options.getListOptions();
//        mImageLoader = ImageLoader.getInstance();
////        for(CategoryVO menu:mMenuList){
////            mItemCount+=menu.getSubcategories().size();
////        }
//    }
//
//    @Override
//    public int getItemViewType(int position) {
////        int sum=0;
////        for(CategoryVO menu:mMenuList){
////            if(position==sum){
////                return MENU_TYPE;
////            }
////            sum+=menu.getSubcategories().size()+1;
////        }
////        return DISH_TYPE;
//
//        if(mMenuList.get(position).getSubcategories()!=null){
//            return MENU_TYPE;
//        }else{
//            return DISH_TYPE;
//        }
//
//    }
//
//    @Override
//    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
//        if(viewType==MENU_TYPE){
//            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.right_menu_item, parent, false);
//            MenuViewHolder viewHolder = new MenuViewHolder(view);
//            return viewHolder;
//        }else{
//            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.right_dish_item1, parent, false);
//            DishViewHolder viewHolder = new DishViewHolder(view);
//            return viewHolder;
//        }
//    }
//
//    @Override
//    public void onBindViewHolder(RecyclerView.ViewHolder holder, final int position) {
//        if(getItemViewType(position)==MENU_TYPE){
//            MenuViewHolder menuholder = (MenuViewHolder)holder;
//            if(menuholder!=null) {
////                menuholder.right_menu_title.setText(getMenuByPosition(position).getName());
//                menuholder.right_menu_title.setText(mMenuList.get(position).getName());
//                menuholder.right_menu_layout.setContentDescription(position+"");
//            }
//        }else {
//            final DishViewHolder dishholder = (DishViewHolder) holder;
//            if (dishholder != null) {
//
////                final CategoryVO dish = getDishByPosition(position);
//                final CategoryVO dish=   mMenuList.get(position);
//
//                dishholder.child_itme.setText(dish.getName());
////                Picasso.with(mContext).load(dish.getIcon_url()).into(dishholder.image);
//                mImageLoader.displayImage(dish.getIcon_url(), dishholder.image, mOptions);
////                dishholder.right_dish_price_tv.setText("------------");
////                dishholder.right_dish_layout.setContentDescription(position+"");
//
//                int count = 0;
////                if(shopCart.getShoppingSingleMap().containsKey(dish)){
////                    count = shopCart.getShoppingSingleMap().get(dish);
////                }
////                if(count<=0){
////                    dishholder.right_dish_remove_iv.setVisibility(View.GONE);
////                    dishholder.right_dish_account_tv.setVisibility(View.GONE);
////                }else {
////                    dishholder.right_dish_remove_iv.setVisibility(View.VISIBLE);
////                    dishholder.right_dish_account_tv.setVisibility(View.VISIBLE);
////                    dishholder.right_dish_account_tv.setText(count+"");
////                }
////                dishholder.right_dish_add_iv.setOnClickListener(new View.OnClickListener() {
////                    @Override
////                    public void onClick(View view) {
////                        if(shopCart.addShoppingSingle(dish)) {
////                            notifyItemChanged(position);
////                            if(shopCartImp!=null)
////                                shopCartImp.add(view,position);
////                        }
////                    }
////                });
////
////                dishholder.right_dish_remove_iv.setOnClickListener(new View.OnClickListener() {
////                    @Override
////                    public void onClick(View view) {
////                        if(shopCart.subShoppingSingle(dish)){
////                            notifyItemChanged(position);
////                            if(shopCartImp!=null)
////                                shopCartImp.remove(view,position);
////                        }
////                    }
////                });
//            }
//        }
//    }
//
//
////    public CategoryVO getMenuByPosition(int position){
////        int sum =0;
////        for(CategoryVO menu:mMenuList){
////            if(position==sum){
////                return menu;
////            }
////            sum+=menu.getSubcategories().size()+1;
////        }
////        return null;
////    }
////
////    public CategoryVO    getDishByPosition(int position){
////        for(CategoryVO menu:mMenuList){
////            if(position>0 && position<=menu.getSubcategories().size()){
////                return menu.getSubcategories().get(position-1);
////            }
////            else{
////                position-=menu.getSubcategories().size()+1;
////            }
////        }
////        return null;
////    }
////
//    public CategoryVO getMenuOfMenuByPosition(int position){
//        for(CategoryVO menu:mMenuList){
//            if(position==0)return menu;
//            if(position>0 && position<=menu.getSubcategories().size()){
//                return menu;
//            }
//            else{
//                position-=menu.getSubcategories().size()+1;
//            }
//        }
//        return null;
//    }
//
//    @Override
//    public int getItemCount() {
//        return mMenuList.size();
//    }
//
////    public ShopCartInterface getShopCartInterface() {
////        return shopCartImp;
////    }
////
////    public void setShopCartInterface(ShopCartInterface shopCartImp) {
////        this.shopCartImp = shopCartImp;
////    }
//
//    private class MenuViewHolder extends RecyclerView.ViewHolder{
//        private LinearLayout right_menu_layout;
//        private TextView right_menu_title;
//        public MenuViewHolder(View itemView) {
//            super(itemView);
//            right_menu_layout = (LinearLayout)itemView.findViewById(R.id.right_menu_item);
//            right_menu_title = (TextView)itemView.findViewById(R.id.right_menu_tv);
//        }
//    }
//
//    private class DishViewHolder extends RecyclerView.ViewHolder{
//        private TextView child_itme;
//        private ImageView image;
////        private TextView right_dish_price_tv;
////        private LinearLayout right_dish_layout;
////        private ImageView right_dish_remove_iv;
////        private ImageView right_dish_add_iv;
////        private TextView right_dish_account_tv;
//
//        public DishViewHolder(View itemView) {
//            super(itemView);
//            child_itme = (TextView)itemView.findViewById(R.id.child_itme);
//            image= (ImageView)itemView.findViewById(R.id.img);
////            right_dish_price_tv = (TextView)itemView.findViewById(R.id.right_dish_price);
////            right_dish_layout = (LinearLayout)itemView.findViewById(R.id.right_dish_item);
////            right_dish_remove_iv = (ImageView)itemView.findViewById(R.id.right_dish_remove);
////            right_dish_add_iv = (ImageView)itemView.findViewById(R.id.right_dish_add);
////            right_dish_account_tv = (TextView) itemView.findViewById(R.id.right_dish_account);
//        }
//
//    }
}
