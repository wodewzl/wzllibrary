package com.xiaojing.shop.adapter;

import android.content.Context;
import android.graphics.Color;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.Toast;

import com.wuzhanglong.library.ItemDecoration.StickyHeaderAdapter;
import com.wuzhanglong.library.adapter.LRecyclerBaseAdapter;
import com.wuzhanglong.library.view.ScaleTransitionPagerTitleView;
import com.xiaojing.shop.R;
import com.xiaojing.shop.mode.CategoryVO;

import net.lucode.hackware.magicindicator.MagicIndicator;
import net.lucode.hackware.magicindicator.buildins.UIUtil;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.CommonNavigator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.CommonNavigatorAdapter;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.abs.IPagerTitleView;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.indicators.LinePagerIndicator;
import net.lucode.hackware.magicindicator.buildins.commonnavigator.titles.SimplePagerTitleView;

import java.util.ArrayList;

/**
 * Created by Administrator on 2017/2/13.
 */

public class OneShopRAdapter extends LRecyclerBaseAdapter<CategoryVO> implements
        StickyHeaderAdapter<OneShopRAdapter.HeaderHolder> {
    private LayoutInflater mInflater;
    private Context mContext;
    private String[] mTitleDataList={"人气","进度","最新揭晓"};
    private ArrayList<Fragment> mFragmentList;
    private HeaderHolder mHeaderHolder;

    public OneShopRAdapter(Context context) {
        mContext = context;
        mInflater = LayoutInflater.from(context);
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        final View view = mInflater.inflate(R.layout.one_shop_item_type3, viewGroup, false);
        return new ViewHolder(view);
    }


    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        super.onBindViewHolder(holder, position);
        ViewHolder oneShopHolder= (ViewHolder) holder;
//
//                BaseActivity activity= (BaseActivity) mContext;
//        mFragmentList=new ArrayList<>();
//        mFragmentList.add(OneShopFragment1.newInstance());
//        mFragmentList.add(OneShopFragment2.newInstance());
//        mFragmentList.add(OneShopFragment3.newInstance());
//        oneShopHolder.viewPager.setAdapter(new FragmentPagerAdapter(activity.getSupportFragmentManager()) {
//            @Override
//            public Fragment getItem(int position) {
//                return mFragmentList.get(position);
//            }
//
//            @Override
//            public int getCount() {
//                return mFragmentList.size();
//            }
//        });
//
        initMagicIndicator(mHeaderHolder.header,oneShopHolder.viewPager);
    }

    @Override
    public long getHeaderId(int position) {
        //原理是这样的 11112222333334444444 同样字段是一组
        if (position > 0) {
            return 1;
        } else {
            return 2;
        }

    }

    @Override
    public int getItemCount() {
        return 15;
    }

    @Override
    public HeaderHolder onCreateHeaderViewHolder(ViewGroup parent) {
        final View view = mInflater.inflate(R.layout.one_shop_item_type2, parent, false);
        mHeaderHolder=new HeaderHolder(view);
        return mHeaderHolder;
    }

    @Override
    public void onBindHeaderViewHolder(final HeaderHolder headerHolder, final int position) {
//        viewholder.header.setText("Header " + getHeaderId(position));
        headerHolder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(mContext, "onBindHeaderViewHolder item clicked position = " + position, Toast.LENGTH_SHORT).show();
            }
        });


        if (getHeaderId(position) == 2) {
            headerHolder.header.setVisibility(View.GONE);
        } else {
            headerHolder.header.setVisibility(View.VISIBLE);

        }
    }

    private void initMagicIndicator(MagicIndicator magicIndicator, final ViewPager viewpager) {
//        MagicIndicator magicIndicator = (MagicIndicator) findViewById(R.id.magic_indicator);
        magicIndicator.setBackgroundColor(Color.WHITE);
        CommonNavigator commonNavigator = new CommonNavigator(mContext);
        commonNavigator.setAdjustMode(true);
        commonNavigator.setAdapter(new CommonNavigatorAdapter() {
            @Override
            public int getCount() {
                return mTitleDataList == null ? 0 : mTitleDataList.length;
            }

            @Override
            public IPagerTitleView getTitleView(Context context, final int index) {
                SimplePagerTitleView simplePagerTitleView = new ScaleTransitionPagerTitleView(context);
                simplePagerTitleView.setText(mTitleDataList[index]);
                simplePagerTitleView.setTextSize(18);
                simplePagerTitleView.setNormalColor(Color.parseColor("#616161"));
                simplePagerTitleView.setSelectedColor(Color.parseColor("#f57c00"));
                simplePagerTitleView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
//                        viewpager.setCurrentItem(index);
                    }
                });
                return simplePagerTitleView;
            }

            @Override
            public IPagerIndicator getIndicator(Context context) {
                LinePagerIndicator indicator = new LinePagerIndicator(context);
                indicator.setStartInterpolator(new AccelerateInterpolator());
                indicator.setEndInterpolator(new DecelerateInterpolator(1.6f));
//                indicator.setYOffset(UIUtil.dip2px(context, 39));
                indicator.setLineHeight(UIUtil.dip2px(context, 2));
                indicator.setColors(Color.parseColor("#f57c00"));
//                LinePagerIndicator indicator = new LinePagerIndicator(context);
//                indicator.setColors(Color.parseColor("#40c4ff"));
                return indicator;
            }

            @Override
            public float getTitleWeight(Context context, int index) {
                if (index == 0) {
                    return 1.0f;
                } else if (index == 1) {
                    return 1.0f;
                } else {
                    return 1.0f;
                }
            }
        });

//        initViewPagerData();
        magicIndicator.setNavigator(commonNavigator);
//        ViewPagerHelper.bind(magicIndicator, viewpager);
    }


    public void initViewPagerData(){
//        BaseActivity activity= (BaseActivity) mContext;
//        mFragmentList=new ArrayList<>();
//        mFragmentList.add(OneShopFragment1.newInstance());
//        mFragmentList.add(OneShopFragment2.newInstance());
//        mFragmentList.add(OneShopFragment3.newInstance());
//        mViewPager.setAdapter(new FragmentPagerAdapter(activity.getSupportFragmentManager()) {
//            @Override
//            public Fragment getItem(int position) {
//                return mFragmentList.get(position);
//            }
//
//            @Override
//            public int getCount() {
//                return mFragmentList.size();
//            }
//        });

    }




    static class ViewHolder extends RecyclerView.ViewHolder {
        public ViewPager viewPager;

        public ViewHolder(View itemView) {
            super(itemView);
//            item = (TextView) itemView;
            viewPager= (ViewPager) itemView.findViewById(R.id.view_pager);
        }
    }

    static class HeaderHolder extends RecyclerView.ViewHolder {
        public MagicIndicator header;

        public HeaderHolder(View itemView) {
            super(itemView);
            header = (MagicIndicator) itemView.findViewById(R.id.magic_indicator);
        }
    }

}
