package com.xiaojing.shop.mode;

import com.wuzhanglong.library.mode.BaseVO;

import java.io.Serializable;

/**
 * Created by ${Wuzhanglong} on 2017/4/25.
 */

public class UserInfoVO extends BaseVO implements Serializable{
    private UserInfoVO datas;
    private String username;
    private String userid;
    private String key;


    public UserInfoVO getDatas() {
        return datas;
    }

    public void setDatas(UserInfoVO datas) {
        this.datas = datas;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
    }
}
