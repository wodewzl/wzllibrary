package com.xiaojing.shop.adapter;

import android.support.v7.widget.RecyclerView;

import com.daidingkang.SnapUpCountDownTimerView;
import com.wuzhanglong.library.adapter.RecyclerBaseAdapter;
import com.xiaojing.shop.R;
import com.xiaojing.shop.mode.HomeVO;

import cn.bingoogolapple.androidcommon.adapter.BGAViewHolderHelper;

/**
 * Created by Administrator on 2017/2/13.
 */

public class OneShopRAdapter3 extends RecyclerBaseAdapter<HomeVO> {
    public OneShopRAdapter3(RecyclerView recyclerView) {
        super(recyclerView, R.layout.one_shop_item3);
    }

    @Override
    public void initData(BGAViewHolderHelper helper, int position, Object model) {
//        helper.setText(R.id.name,"我草草草");

//        ImageView itemLayout=helper.getView(R.id.status_img);

//        itemLayout.setBackgroundDrawable(BaseCommonUtils.setBackgroundShap(mContext,BaseCommonUtils.dip2px(mContext,5),R.color.C15,R.color.C15));
        SnapUpCountDownTimerView rushBuyCountDownTimerView =helper.getView(R.id.timer_view);
        rushBuyCountDownTimerView.setTime(1,55,3);//设置小时，分钟，秒。注意不能大于正常值，否则会抛出异常
        rushBuyCountDownTimerView.start();//开始倒计时

    }

    @Override
    public int getItemCount() {
        return 15;
    }

    @Override
    public int getItemViewType(int position) {
        return R.layout.one_shop_item3;
    }
}
