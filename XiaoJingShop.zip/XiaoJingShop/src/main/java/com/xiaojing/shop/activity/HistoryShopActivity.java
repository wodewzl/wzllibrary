package com.xiaojing.shop.activity;

import android.support.v7.widget.LinearLayoutManager;

import com.github.jdsjlzx.recyclerview.LuRecyclerView;
import com.github.jdsjlzx.recyclerview.LuRecyclerViewAdapter;
import com.wuzhanglong.library.ItemDecoration.DividerDecoration;
import com.wuzhanglong.library.activity.BaseActivity;
import com.wuzhanglong.library.mode.BaseVO;
import com.wuzhanglong.library.utils.DividerUtil;
import com.wuzhanglong.library.view.AutoSwipeRefreshLayout;
import com.xiaojing.shop.R;
import com.xiaojing.shop.adapter.HistoryShopRadapter;

public class HistoryShopActivity extends BaseActivity {
    private AutoSwipeRefreshLayout mAutoSwipeRefreshLayout;
    private LuRecyclerView mRecyclerView;
    private HistoryShopRadapter mHistoryShopRadapter;

    @Override
    public void baseSetContentView() {
        contentInflateView(R.layout.history_shop_activity);
    }

    @Override
    public void initView() {
        mRecyclerView = getViewById(R.id.recycler_view);
        mRecyclerView.setLayoutManager(new LinearLayoutManager(mActivity));
        mHistoryShopRadapter = new HistoryShopRadapter(mRecyclerView);
        LuRecyclerViewAdapter adapter = new LuRecyclerViewAdapter(mHistoryShopRadapter);
        mRecyclerView.setAdapter(adapter);
//        DividerDecoration divider = new DividerDecoration.Builder(mActivity)
//                .setHeight(R.dimen.dp_1)
//                .setColorResource(R.color.C3_1)
//                .build();
//        mRecyclerView.addItemDecoration(divider);
        DividerDecoration divider = DividerUtil.linnerDivider(this,R.dimen.dp_1,R.color.C3_1);
        mRecyclerView.addItemDecoration(divider);

    }

    @Override
    public void bindViewsListener() {

    }

    @Override
    public void getData() {
        showView();
    }

    @Override
    public void hasData(BaseVO vo) {

    }

    @Override
    public void noData(BaseVO vo) {

    }

    @Override
    public void noNet() {

    }

}
