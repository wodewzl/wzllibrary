package com.xiaojing.shop.constant;

import cz.msebera.android.httpclient.protocol.HTTP;

public class Constant {

	public static final String FIRSTID = "firstid";
	public static final String LASTID = "lastid";
	public static final String ENCODING = HTTP.UTF_8;
//	public static final String SDCARD_CACHE = "com.synews/files/"; // 文件sdk缓存


	//get 最后加 &
	public static final String LOGIN_URL = "act=login&op=index";// 登录接口
	public static final String GET_CODE = "act=connect&op=get_sms_captcha&";// 获取验证码
	public static final String REGIST_URL = "act=connect&op=sms_register";// 注册
	public static final String CATEGORY_URL = "act=goods_class&op=index&";// 获取验证码




}
