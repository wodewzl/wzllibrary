
package com.beisheng.bsims.interfaces;

public interface DataChangedListener {
    public abstract void dataChanged();
}
