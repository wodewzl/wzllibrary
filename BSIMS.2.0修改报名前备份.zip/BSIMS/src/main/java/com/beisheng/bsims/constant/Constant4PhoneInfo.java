package com.beisheng.bsims.constant;

/** 
 * @author peck
 * @Description:   手机信息
 * @date 2015-6-8 下午6:38:23 
 * @email  971371860@qq.com
 * @version V1.0 
 */

public class Constant4PhoneInfo {
	
	/**
	 * 手机信息
	 */
	public static final String SENDMYPHONEINFO_PATH = "api.php/Pmodel/modelUpdate/";

}
