
package com.beisheng.bsims.interfaces;

public interface RecordResult {
    void getRecordResult(String result);
}
