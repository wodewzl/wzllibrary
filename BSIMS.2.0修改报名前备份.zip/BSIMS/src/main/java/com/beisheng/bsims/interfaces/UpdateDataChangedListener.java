
package com.beisheng.bsims.interfaces;

public interface UpdateDataChangedListener {
    public abstract void updateData();
}
