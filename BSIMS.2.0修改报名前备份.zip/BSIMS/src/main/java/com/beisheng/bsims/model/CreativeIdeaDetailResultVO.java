
package com.beisheng.bsims.model;

public class CreativeIdeaDetailResultVO {
    private CreativeIdeaDetailVO info;
    private String code;
    private String retinfo;
    private String system_time;

    public CreativeIdeaDetailVO getInfo() {
        return info;
    }

    public void setInfo(CreativeIdeaDetailVO info) {
        this.info = info;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getRetinfo() {
        return retinfo;
    }

    public void setRetinfo(String retinfo) {
        this.retinfo = retinfo;
    }

    public String getSystem_time() {
        return system_time;
    }

    public void setSystem_time(String system_time) {
        this.system_time = system_time;
    }

}
