/**
 * 
 */
package com.beisheng.bsims.chatutils;

/**

 *          BS北盛最帅程序员

 *         Copyright (c) 2016

 *        湖北北盛科技有限公司

 *        @author 梁骚侠
 
 *        @date 2016-4-25

 *        @version 2.0

 */

/**
 * Sdk回调接受者
 * 
 * @author zhuqian
 */
public interface IObserverListener {
    void notify(int sdkStatus);
}