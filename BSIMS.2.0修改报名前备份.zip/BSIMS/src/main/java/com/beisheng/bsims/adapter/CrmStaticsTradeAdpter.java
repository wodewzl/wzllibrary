
package com.beisheng.bsims.adapter;

import android.content.Context;

import com.beisheng.bsims.model.CrmStaticsTradeVO;

public class CrmStaticsTradeAdpter extends BSBaseAdapter<CrmStaticsTradeVO> {

    public CrmStaticsTradeAdpter(Context context) {
        super(context);
    }
}
