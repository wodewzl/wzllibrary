
package com.beisheng.bsims.model;

public class AttendanceResultVO {
    private AttendanceVO array;
    private String code;
    private String retinfo;
    private String system_time;

    public AttendanceVO getArray() {
        return array;
    }

    public void setArray(AttendanceVO array) {
        this.array = array;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getRetinfo() {
        return retinfo;
    }

    public void setRetinfo(String retinfo) {
        this.retinfo = retinfo;
    }

    public String getSystem_time() {
        return system_time;
    }

    public void setSystem_time(String system_time) {
        this.system_time = system_time;
    }

}
