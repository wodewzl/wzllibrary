
package com.beisheng.bsims.activity;

import android.os.Bundle;
import android.support.v4.app.FragmentActivity;

import com.beisheng.bsims.R;

public class EmployeeRecordsActivity extends FragmentActivity {
    @Override
    protected void onCreate(Bundle arg0) {
        super.onCreate(arg0);
        setContentView(R.layout.employee_records);
    }
}
