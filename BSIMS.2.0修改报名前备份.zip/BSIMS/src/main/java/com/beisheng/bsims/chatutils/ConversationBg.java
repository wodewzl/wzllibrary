/**
 * 
 */
package com.beisheng.bsims.chatutils;

/**

 *          BS北盛最帅程序员

 *         Copyright (c) 2016

 *        湖北北盛科技有限公司

 *        @author 梁骚侠
 
 *        @date 2016-7-15

 *        @version 2.0

 */
public class ConversationBg {
    private String id;
    private String account;
    private String targetId;
    private String bgPath;
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getAccount() {
        return account;
    }
    public void setAccount(String account) {
        this.account = account;
    }
    public String getTargetId() {
        return targetId;
    }
    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }
    public String getBgPath() {
        return bgPath;
    }
    public void setBgPath(String bgPath) {
        this.bgPath = bgPath;
    }
}
