
package com.beisheng.bsims.interfaces;

public class UpdateDataChangedListenerImp implements UpdateDataChangedListener {

    @Override
    public void updateData() {

    }

}
